### Project Healthcare

To run

```bash
npm install
npm run dev
```

if node is not installed, download & install it from https://nodejs.org/en for your OS.
