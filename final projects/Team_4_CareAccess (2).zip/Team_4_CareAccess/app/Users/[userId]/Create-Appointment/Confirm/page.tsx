import Image from 'next/image';
import Link from 'next/link';

import { Button } from '@/components/styling/button';
import { Doctors } from '@/constants';
import { retrieveAppointment } from '@/controller/operations/appointment.operations';
import { formatDateTime } from '@/controller/utils';

const ActionSucceeded = async ({
  searchParams,
  params: { userId },
}: SearchParamProps) => {
  const appointmentId =
    (searchParams?.appointmentId as string) ||
    '';
  const patientAppointment =
    await retrieveAppointment(
      appointmentId,
    );

  const doctor = Doctors.find(
    (doctor) =>
      doctor.name ===
      patientAppointment.primaryPhysician,
  );

  return (
    <div className=" flex h-screen max-h-screen px-[5%]">
      <div className="Confirmed-img">
        <Link href="/">
          <Image
            src="/assets/icons/Frontpage.svg"
            height={1000}
            width={1000}
            alt="logo"
            className="h-10 w-fit"
          />
        </Link>

        <section className="flex flex-col items-center">
          <Image
            src="/assets/gifs/Confirmed.gif"
            height={300}
            width={280}
            alt="Confirmed"
          />
          <h2 className="header mb-6 max-w-[600px] text-center">
            We've successfully scheduled
            your{' '}
            <span className="text-green-500">
              appointment
            </span>
            !
          </h2>
          <p>
            Our team will reach out soon
            to confirm your appointment.
          </p>
        </section>

        <section className="request-details">
          <p>
            Requested appointment
            details:{' '}
          </p>
          <div className="flex items-center gap-3">
            <Image
              src={doctor?.image!}
              alt="doctor"
              width={100}
              height={100}
              className="size-6"
            />
            <p className="whitespace-nowrap">
              Dr. {doctor?.name}
            </p>
          </div>
          <div className="flex gap-2">
            <Image
              src="/assets/icons/calendar.svg"
              height={24}
              width={24}
              alt="calendar"
            />
            <p>
              {' '}
              {
                formatDateTime(
                  patientAppointment.schedule,
                ).dateTime
              }
            </p>
          </div>
        </section>

        <Button
          variant="outline"
          className="shad-primary-btn"
          asChild
        >
          <Link
            href={`/Users/${userId}/Create-Appointment`}
          >
            New Appointment
          </Link>
        </Button>

        <p className=""> CareAccess</p>
      </div>
    </div>
  );
};

export default ActionSucceeded;
