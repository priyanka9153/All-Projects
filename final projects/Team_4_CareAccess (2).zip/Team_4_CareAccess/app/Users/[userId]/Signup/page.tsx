import { redirect } from 'next/navigation';
import RegisterForm from '@/components/forms/RegisterForm';
import {
  getPatient,
  getUser,
} from '@/controller/operations/user.operations';

const Register = async ({
  params: { userId },
}: SearchParamProps) => {
  const user = await getUser(userId);
  const patient =
    await getPatient(userId);

  if (patient)
    redirect(
      `/Users/${userId}/Create-Appointment`,
    );

  const hour = new Date().getHours();
  const greeting =
    hour < 12
      ? 'Good Morning'
      : hour < 18
        ? 'Good Afternoon'
        : 'Good Evening';

  return (
    <div className="flex h-screen bg-gray-100">
      <div className="container mx-auto max-w-4xl p-10">
        <h1 className="text-xl font-semibold mb-4">
          {greeting} 👋
        </h1>
        <RegisterForm user={user} />
        <p className="py-12 text-center text-lg">
          CareAccess
        </p>
      </div>
    </div>
  );
};

export default Register;
