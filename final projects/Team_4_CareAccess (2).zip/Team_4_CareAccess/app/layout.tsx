import type { Metadata } from 'next';
import './globals.css';
import { Merriweather as FontSerif } from 'next/font/google';
import { ThemeProvider } from 'next-themes';

import { cn } from '@/controller/utils';

const fontSerif = FontSerif({
  subsets: ['latin'],
  weight: ['400', '700'],
  variable: '--font-serif',
});

export const metadata: Metadata = {
  title: 'CareAccess - Simplifying Healthcare',
  description:
    'CareAccess is an advanced healthcare management platform designed to simplify patient registration, appointment scheduling, and medical records management for modern healthcare providers.',
  icons: {
    icon: '/assets/icons/logo-icon.svg',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={cn(
          'min-h-screen bg-light-100 text-gray-800 font-serif antialiased',
          fontSerif.variable
        )}
        style={{
          margin: '0 auto',
          padding: '0 1.5rem',
        }}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          themes={['light', 'dark']}
        >
          <div
            className="container mx-auto max-w-6xl p-6"
            style={{
              boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
              borderRadius: '12px',
            }}
          >
            {children}
          </div>
        </ThemeProvider>
        <footer
          className="text-center text-sm mt-8"
          style={{
            color: '#4A5568',
            borderTop: '1px solid #E2E8F0',
            padding: '1rem 0',
          }}
        >
          © {new Date().getFullYear()} CareAccess. Your partner in healthcare innovation.
        </footer>
      </body>
    </html>
  );
}
