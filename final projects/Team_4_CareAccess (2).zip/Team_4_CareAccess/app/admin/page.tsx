import Image from 'next/image';
import Link from 'next/link';

import { DashboardCard } from '@/components/DashboardCard';
import { appointmentTableColumns } from '@/components/table/appointmentTableFields';
import { AdminDataTable } from '@/components/table/AdminDataTable';
import { fetchRecentAppointments } from '@/controller/operations/appointment.operations';

const Admin = async () => {
  const appointmentData = await fetchRecentAppointments();

  return (
    <div className="mx-auto flex max-w-6xl flex-col space-y-12 bg-gray-50 text-gray-800">
      <header className="dashboard-header flex justify-between items-center py-5 px-8 border-b border-gray-300 bg-white shadow-md">
        <Link
          href="/"
          className="cursor-pointer"
        >
          <Image
            src="/assets/icons/Frontpage.svg"
            height={36}
            width={170}
            alt="logo"
            className="h-9 w-fit"
          />
        </Link>
        <p className="text-2xl font-semibold tracking-wide">
          Admin Portal
        </p>
      </header>

      <main className="dashboard-main px-8 space-y-12">
        {/* Welcome Section */}
        <section className="w-full flex flex-col lg:flex-row items-center space-y-6 lg:space-y-0 lg:space-x-8">
          <div className="flex-shrink-0">
            <svg
              className="w-28 h-28 text-green-500"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 64 64"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M16 32a16 16 0 1132 0 16 16 0 01-32 0z"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M32 16v16l8 8"
              />
            </svg>
          </div>
          <div>
            <h1 className="text-4xl font-extrabold flex items-center">
              Welcome to Your Dashboard
            </h1>
            <p className="text-lg text-gray-700 mt-2">
              Start your day by managing
              appointments, viewing
              stats, and taking action.
            </p>
          </div>
        </section>

        {/* Statistics Section */}
        <section className="admin-stat grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          <DashboardCard
            type="appointmentData"
            count={appointmentData.confirmedAppointments}
            label="Confirmed Appointments"
            icon={'/assets/icons/bookings.svg'}
            className="p-6 bg-blue-100 rounded-lg shadow-lg hover:bg-blue-200 transition duration-300"
          />
          <DashboardCard
            type="pending"
            count={appointmentData.awaitingConfirmation}
            label="Pending Appointments"
            icon={'/assets/icons/onhold.svg'}
            className="p-6 bg-yellow-100 rounded-lg shadow-lg hover:bg-yellow-200 transition duration-300"
          />
          <DashboardCard
            type="cancelled"
            count={appointmentData.cancelledAppointments}
            label="Cancelled Appointments"
            icon={'/assets/icons/Abondoned.svg'}
            className="p-6 bg-red-100 rounded-lg shadow-lg hover:bg-red-200 transition duration-300"
          />
        </section>

        {/* Table Section */}
        <section className="admin-table mt-10 bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-bold mb-6">
            Recent Appointments
          </h2>
          <AdminDataTable
            columns={appointmentTableColumns}
            data={appointmentData.documents}
          />
        </section>
      </main>
    </div>
  );
};

export default Admin;
