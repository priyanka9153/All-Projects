import Image from 'next/image';

export default function Loading() {
  return (
    <div
      className="flex items-center justify-center w-full h-screen gap-5 bg-gray-900 text-gray-200"
      style={{
        backgroundImage: 'linear-gradient(45deg, #1e3a8a, #2563eb)',
        textAlign: 'center',
      }}
    >
      <Image
        src="/assets/icons/loader.svg"
        alt="Loading spinner"
        width={60} // Changed width
        height={60} // Adjusted height
        className="animate-spin"
        style={{
          animationDuration: '1.2s',
          filter: 'drop-shadow(0 4px 6px rgba(0, 0, 0, 0.2))',
        }}
      />
      <span
        className="text-lg font-semibold tracking-wider"
        style={{
          textTransform: 'uppercase',
          letterSpacing: '2px',
        }}
      >
        Loading, please wait...
      </span>
    </div>
  );
}
