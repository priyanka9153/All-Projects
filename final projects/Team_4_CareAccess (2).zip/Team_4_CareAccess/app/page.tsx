import Image from 'next/image';
import Link from 'next/link';
import { NewPatient } from '@/components/forms/PatientSignup';
import { Verificationkey } from '@/components/Verificationkey';

interface SearchParamProps {
  searchParams?: {
    admin?: string;
  };
}

const Frontpage = ({
  searchParams,
}: SearchParamProps) => {
  const isAdmin =
    searchParams?.admin === 'true';

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-gradient-to-r from-blue-100 via-gray-50 to-green-100">
      {isAdmin && <Verificationkey />}

      {/* Left Section */}
      <section className="flex-1 flex justify-center items-center mx-auto my-6 px-4 md:px-8 lg:px-12 bg-white shadow-xl rounded-lg lg:rounded-r-none">
        <div className="max-w-4xl mx-auto py-8">
          {/* Logo */}
          <div className="w-full flex justify-center lg:justify-start">
            <Image
              src="/assets/icons/Frontpage.svg"
              height={64}
              width={64}
              alt="CareAccess"
              className="mb-6 h-14 w-auto"
              priority
            />
          </div>

          {/* Welcome Text */}
          <h1 className="text-2xl md:text-3xl font-extrabold text-gray-800 leading-snug mb-4 text-center lg:text-left">
            Seamless{' '}
            <span className="text-green-600">
              Patient Management
            </span>
          </h1>
          <p className="text-gray-600 text-sm md:text-base mb-8 text-center lg:text-left">
            Book appointments, manage
            patient records, and stay
            connected—all in one
            platform designed to make
            healthcare management
            effortless.
          </p>

          {/* Patient Form */}
          <div className="w-full flex justify-center">
            <NewPatient />
          </div>

          {/* Admin Link */}
          <div className="mt-6 text-center lg:text-left">
            <a
              href="/?admin=true"
              className="inline-flex items-center text-green-600 font-semibold hover:text-green-700 bg-green-50 hover:bg-green-100 px-4 py-2 rounded-lg shadow transition-all duration-300"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="w-5 h-5 mr-2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M8 9l4-4 4 4m0 6l-4 4-4-4"
                />
              </svg>
              Admin Panel
            </a>
          </div>
        </div>
      </section>

      {/* Right Section */}
      <div className="flex-1 hidden lg:flex bg-gradient-to-t from-green-50 to-blue-50 relative items-center justify-center">
        {/* Background Image */}
        <Image
          src="/assets/images/onboarding-img.png"
          layout="fill"
          objectFit="cover"
          alt="CareAccess Onboarding"
          className="rounded-l-lg shadow-inner"
          priority
        />
      </div>
    </div>
  );
};

export default Frontpage;
