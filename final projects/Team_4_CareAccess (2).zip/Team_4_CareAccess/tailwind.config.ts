import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class', // Enable dark mode based on a class ('class') or OS settings ('media')
  content: [
    './pages/**/*.{ts,tsx}', // Paths to all template files
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  theme: {
    container: {
      center: true,
      padding: '2rem',
      screens: {
        '2xl': '1400px',
      },
    },
    extend: {
      colors: {
        primary: {
          500: '#007BFF', // Vivid Blue for primary actions
          600: '#0056B3', // Darker Blue for hover states
          700: '#004080', // Deep Blue for active states
        },
        secondary: {
          500: '#28A745', // Vibrant Green for success states
          600: '#1E7A34', // Deep Green for success hover states
          700: '#155228', // Darker Green for success active states
        },
        red: {
          500: '#DC3545', // Bright Red for errors and warnings
          600: '#C82333', // Dark Red for error hover states
          700: '#A71D2A', // Darker Red for error active states
        },
        light: {
          200: '#F8F9FA', // Light Gray for backgrounds
          300: '#E9ECEF', // Off White for card backgrounds
          400: '#DEE2E6', // Grayish White for borders
        },
        dark: {
          500: '#343A40', // Dark Gray for text
          600: '#23272B', // Darker Gray for headings
          700: '#1B1E21', // Almost Black for footer backgrounds
        },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        serif: [
          'Merriweather',
          'serif',
        ],
      },
      fontSize: {
        xs: [
          '0.75rem',
          { lineHeight: '1rem' },
        ],
        sm: [
          '0.875rem',
          { lineHeight: '1.25rem' },
        ],
        base: [
          '1rem',
          { lineHeight: '1.5rem' },
        ],
        lg: [
          '1.125rem',
          { lineHeight: '1.75rem' },
        ],
        xl: [
          '1.25rem',
          { lineHeight: '1.75rem' },
        ],
        '2xl': [
          '1.5rem',
          { lineHeight: '2rem' },
        ],
        '3xl': [
          '1.875rem',
          { lineHeight: '2.25rem' },
        ],
        '4xl': [
          '2.25rem',
          { lineHeight: '2.5rem' },
        ],
        '5xl': [
          '3rem',
          { lineHeight: '1' },
        ],
      },
      spacing: {
        '1': '0.25rem',
        '2': '0.5rem',
        '3': '0.75rem',
        '4': '1rem',
        '5': '1.25rem',
        '6': '1.5rem',
        '8': '2rem',
        '10': '2.5rem',
        '12': '3rem',
        '14': '3.5rem',
        '16': '4rem',
        '20': '5rem',
        '24': '6rem',
        '28': '7rem',
        '32': '8rem',
      },
      borderRadius: {
        none: '0',
        sm: '0.125rem',
        DEFAULT: '0.25rem',
        md: '0.375rem',
        lg: '0.5rem',
        xl: '0.75rem',
        '2xl': '1rem',
        '3xl': '1.5rem',
      },
      borderWidth: {
        DEFAULT: '1px',
        '0': '0',
        '2': '2px',
        '4': '4px',
        '8': '8px',
      },
      boxShadow: {
        sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
        DEFAULT:
          '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
        md: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
        xl: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
        '2xl':
          '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
        inner:
          'inset 0 2px 4px 0 rgba(0,0,0,0.06)',
        none: 'none',
      },
    },
  },
  plugins: [
    require('tailwindcss-animate'),
  ],
};

export default config;
