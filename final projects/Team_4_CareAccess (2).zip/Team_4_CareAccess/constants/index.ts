// index.ts

import { Gender } from "@/types";

export const GenderOptions = [
  'Male',
  'Female',
  'Other',
  'Prefer Not to Say',
];

export const PatientSignupDefaultValues =
{
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
  birthDate: new Date(Date.now()),
  gender: 'Male' as Gender,
  address: '',
  occupation: '',
  emergencyContactName: '',
  emergencyContactNumber: '',
  primaryPhysician: '',
  insuranceProvider: '',
  insurancePolicyNumber: '',
  allergies: '',
  currentMedication: '',
  familyMedicalHistory: '',
  pastMedicalHistory: '',
  identificationType: 'Passport',
  identificationNumber: '',
  identificationDocument: [],
  treatmentConsent: false,
  disclosureConsent: false,
  privacyConsent: false,
  preferredLanguage: 'English',
  height: '0 cm',
  weight: '0 kg',
};

export const IdentificationTypes = [
  'Birth Certificate',
  "Driver's License",
  'Medical Insurance Card/Policy',
  'Military ID Card',
  'National Identity Card',
  'Passport',
  'Resident Alien Card (Green Card)',
  'Social Security Card',
  'State ID Card',
  'Student ID Card',
  'Voter ID Card',
  'Work Permit',
];

export const Doctors = [
  {
    image:
      '/assets/images/dr-ashok-seth.png',
    name: 'Ashok Seth',
    specialization: 'Cardiology',
    rating: 4.9,
    experience: '25+ years',
    availability: true,
    consultations: '1000+',
    languages: ['English', 'Hindi'],
    location: 'New Delhi, India',
  },
  {
    image:
      '/assets/images/dr-christiaan-barnard.png',
    name: 'Christiaan Barnard',
    specialization: 'Cardiac Surgery',
    rating: 4.8,
    experience: '30+ years',
    availability: true,
    consultations: '1200+',
    languages: ['English', 'Afrikaans'],
    location: 'Cape Town, South Africa',
  },
  {
    image:
      '/assets/images/dr-devi-shetty.png',
    name: 'Devi Shetty',
    specialization: 'Cardiac Surgery',
    rating: 4.7,
    experience: '35+ years',
    availability: true,
    consultations: '1500+',
    languages: [
      'English',
      'Hindi',
      'Kannada',
    ],
    location: 'Bangalore, India',
  },
  {
    image:
      '/assets/images/dr-elizabeth-kubler-ross.png',
    name: 'Elizabeth Kübler-Ross',
    specialization: 'Psychiatry',
    rating: 4.6,
    experience: '20+ years',
    availability: false,
    consultations: '800+',
    languages: ['English', 'German'],
    location: 'Zurich, Switzerland',
  },
  {
    image:
      '/assets/images/dr-paul-farmer.png',
    name: 'Paul Farmer',
    specialization:
      'Infectious Disease',
    rating: 4.8,
    experience: '25+ years',
    availability: true,
    consultations: '900+',
    languages: [
      'English',
      'French',
      'Creole',
    ],
    location: 'Boston, USA',
  },
  {
    image:
      '/assets/images/dr-ramakanta-panda.png',
    name: 'Ramakanta Panda',
    specialization:
      'Cardiothoracic Surgery',
    rating: 4.9,
    experience: '28+ years',
    availability: true,
    consultations: '1100+',
    languages: [
      'English',
      'Hindi',
      'Odia',
    ],
    location: 'Mumbai, India',
  },
  {
    image:
      '/assets/images/dr-randeep-guleria.png',
    name: 'Randeep Guleria',
    specialization: 'Pulmonology',
    rating: 4.7,
    experience: '22+ years',
    availability: true,
    consultations: '700+',
    languages: [
      'English',
      'Hindi',
      'Punjabi',
    ],
    location: 'New Delhi, India',
  },
  {
    image:
      '/assets/images/dr-sanjay-gupta.png',
    name: 'Sanjay Gupta',
    specialization: 'Neurosurgery',
    rating: 4.8,
    experience: '20+ years',
    availability: false,
    consultations: '950+',
    languages: ['English', 'Hindi'],
    location: 'Atlanta, USA',
  },
  {
    image:
      '/assets/images/dr-william-osler.png',
    name: 'William Osler',
    specialization: 'Internal Medicine',
    rating: 4.6,
    experience: '40+ years',
    availability: false,
    consultations: '1300+',
    languages: ['English', 'French'],
    location: 'Oxford, UK',
  },
];

export const StatusIcon = {
  scheduled: '/assets/icons/check.svg',
  pending: '/assets/icons/pending.svg',
  cancelled:
    '/assets/icons/cancelled.svg',
  rescheduled:
    '/assets/icons/rescheduled.svg',
};

export const Languages = [
  'English',
  'Hindi',
  'Spanish',
  'Mandarin',
  'French',
  'Arabic',
  'Bengali',
  'Russian',
  'Portuguese',
  'Japanese',
];