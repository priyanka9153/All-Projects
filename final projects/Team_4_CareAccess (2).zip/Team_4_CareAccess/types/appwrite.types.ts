import { Models } from 'node-appwrite';
import { Gender, Status } from "@/types";


export interface Patient extends Models.Document {
  userId: string;
  name: string;
  email: string;
  phone: string;
  dateOfBirth: Date;
  gender: Gender;
  residentialAddress: string;
  jobTitle: string;
  emergencyContactPersonName: string;
  emergencyContactPhoneNumber: string;
  primaryCarePhysician: string;
  healthInsuranceProvider: string;
  healthInsurancePolicyNumber: string;
  knownAllergies: string | undefined;
  currentMedications: string | undefined;
  familyMedicalHistoryDetails: string | undefined;
  previousMedicalConditions: string | undefined;
  documentTypeOfIdentification: string | undefined;
  identificationDocumentNumber: string | undefined;
  identificationDocumentFile: FormData | undefined;
  consentForPrivacyPolicy: boolean;
  maritalStatusDescription: string | undefined;
  preferredLanguage: string | undefined;
  preferredContactMethod: string | undefined;
  bloodGroup: string | undefined;
  smokingStatusDescription: string | undefined;
  heightInCm: number | undefined;
  weightInKg: number | undefined;
}

export interface patientAppointment extends Models.Document {
  patient: Patient;
  appointmentSchedule: Date;
  appointmentStatus: Status;
  attendingPhysician: string;
  appointmentReason: string;
  appointmentNote: string;
  userId: string;
  appointmentCancellationReason: string | null;
}
