import { type } from "os";

declare type SearchParamProps = {
  params: { [key: string]: string };
  searchParams: {
    [key: string]: string | string[] | undefined;
  };
};

declare type Gender = 'Male' | 'Female' | 'Other';
declare type Status = 'pending' | 'scheduled' | 'cancelled' | 'completed' | 'rescheduled';

declare interface registerUserParams {
  name: string;
  email: string;
  phone: string;
}

declare interface User extends registerUserParams {
  $id: string;
}

declare interface RegisterUserParams extends registerUserParams {
  userId: string;
  birthDate: Date;
  gender: Gender;
  address: string;
  occupation: string;
  emergencyContactName: string;
  emergencyContactNumber: string;
  primaryPhysician: string;
  insuranceProvider: string;
  insurancePolicyNumber: string;
  allergies: string | undefined;
  currentMedication: string | undefined;
  familyMedicalHistory: string | undefined;
  pastMedicalHistory: string | undefined;
  identificationType: string | undefined;
  identificationNumber: string | undefined;
  identificationDocument: FormData | undefined;
  privacyConsent: boolean;
  maritalStatus: string | undefined;
  languagePreference: string | undefined;
  preferredContactMethod: string | undefined;
  bloodType: string | undefined;
  smokingStatus: string | undefined;
  height: number | undefined;
  weight: number | undefined;
}

declare type scheduleAppointmentParams = {
  userId: string;
  patient: string;
  primaryPhysician: string;
  reason: string;
  schedule: Date;
  status: Status;
  note: string | undefined;
};

declare type modifyAppointmentParams = {
  appointmentId: string;
  userId: string;
  timeZone: string;
  patientAppointment: patientAppointment;
  type: string;
};

