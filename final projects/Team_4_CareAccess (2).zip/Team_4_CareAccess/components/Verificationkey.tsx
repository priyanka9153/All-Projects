'use client';

import Image from 'next/image';
import {
  usePathname,
  useRouter,
} from 'next/navigation';
import {
  useEffect,
  useState,
} from 'react';

import {
  AlertDialog,
  AlertDialogContent,
  DialogHeader as AlertDialogHeader,
  DialogFooter as AlertDialogFooter,
  DialogTitle as AlertDialogTitle,
  DialogDescription as AlertDialogDescription,
  ConfirmAction as AlertDialogAction,
} from '@/components/styling/alert-box';

import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from '@/components/styling/input-otp';
import {
  decryptKey,
  encryptKey,
} from '@/controller/utils';

export const Verificationkey = () => {
  const router = useRouter();
  const path = usePathname();
  const [open, setOpen] =
    useState(false);
  const [passkey, setPasskey] =
    useState('');
  const [error, setError] =
    useState('');

  const encryptedKey =
    typeof window !== 'undefined'
      ? window.localStorage.getItem(
          'accessKey',
        )
      : null;

  useEffect(() => {
    const accessKey =
      encryptedKey &&
      decryptKey(encryptedKey);
    if (path) {
      if (
        accessKey ===
        process.env.NEXT_PUBLIC_ADMIN_PASSWORD!.toString()
      ) {
        setOpen(false);
        router.push('/admin');
      } else {
        setOpen(true);
      }
    }
  }, [encryptedKey, path, router]);

  useEffect(() => {
    console.log(
      'Current passkey state:',
      passkey,
    );
    console.log(
      'Modal open state:',
      open,
    );
    console.log(
      'Current error message:',
      error,
    );
  }, [passkey, open, error]);

  const closeModal = () => {
    setOpen(false);
    router.push('/');
  };

  const validatePasskey = (
    e: React.MouseEvent<
      HTMLButtonElement,
      MouseEvent
    >,
  ) => {
    e.preventDefault();
    if (
      passkey ===
      process.env
        .NEXT_PUBLIC_ADMIN_PASSWORD!
    ) {
      const encryptedKey =
        encryptKey(passkey);
      localStorage.setItem(
        'accessKey',
        encryptedKey,
      );
      setOpen(false);
      router.push('/admin');
    } else {
      setError(
        'Invalid passkey. Please try again.',
      );
    }
  };

  return (
    <AlertDialog
      open={open}
      onOpenChange={setOpen}
    >
      <AlertDialogContent className="max-w-lg mx-auto rounded-2xl bg-white shadow-2xl transform transition-all sm:w-full">
        <div className="bg-gradient-to-r from-blue-600 via-purple-500 to-indigo-700 p-6 rounded-t-2xl">
          <AlertDialogTitle className="flex items-center justify-between text-white font-bold text-lg">
            🔒 Admin Verification
            <Image
              src="/assets/icons/close.svg"
              alt="close"
              width={24}
              height={24}
              onClick={() =>
                closeModal()
              }
              className="cursor-pointer hover:opacity-80"
            />
          </AlertDialogTitle>
        </div>

        <div className="p-8 space-y-6">
          <AlertDialogDescription className="text-gray-800 text-sm">
            Enter the passkey below to
            access the admin page.
          </AlertDialogDescription>
          <InputOTP
            maxLength={6}
            value={passkey}
            onChange={(value) =>
              setPasskey(value)
            }
          >
            <InputOTPGroup className="flex space-x-3">
              {Array.from({
                length: 6,
              }).map((_, index) => (
                <InputOTPSlot
                  key={index}
                  index={index}
                  className="w-12 h-14 text-center border rounded-lg shadow-sm focus:ring-2 focus:ring-blue-400"
                />
              ))}
            </InputOTPGroup>
          </InputOTP>
          {error && (
            <div className="text-red-600 text-sm text-center font-medium">
              {error}
            </div>
          )}
        </div>

        <AlertDialogFooter>
          <button
            onClick={(e) =>
              validatePasskey(e)
            }
            className="bg-gradient-to-r from-green-500 via-teal-500 to-blue-500 text-white py-3 px-5 rounded-xl shadow-md hover:opacity-90 transition-all duration-300 w-full"
          >
            Validate Passkey
          </button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
