'use client';

import { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import Image from 'next/image';
import SubmitButton from './SubmitButton';

const FilePreview = () => {
  const [files, setFiles] = useState<
    File[]
  >([]);
  const [
    isProcessing,
    setIsProcessing,
  ] = useState(false);

  const onDrop = (
    acceptedFiles: File[],
  ) => {
    setFiles(acceptedFiles);
  };

  const processFiles = () => {
    setIsProcessing(true);

    setTimeout(() => {
      console.log(
        'Files processed:',
        files,
      );
      setIsProcessing(false);
    }, 2000);
  };

  const {
    getRootProps,
    getInputProps,
  } = useDropzone({ onDrop });

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md">
      <div
        {...getRootProps()}
        className="border-2 border-dashed rounded-lg p-4 text-center bg-gray-50 hover:bg-gray-100 cursor-pointer"
      >
        <input {...getInputProps()} />
        {files.length > 0 ? (
          <div className="space-y-2">
            {files.map(
              (file, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between bg-gray-100 p-2 rounded-lg shadow-sm"
                >
                  <p className="text-sm text-gray-600 truncate">
                    {file.name}
                  </p>
                  <span className="text-xs text-gray-500">
                    {(
                      file.size / 1024
                    ).toFixed(2)}{' '}
                    KB
                  </span>
                </div>
              ),
            )}
          </div>
        ) : (
          <p className="text-sm text-gray-600">
            Drag and drop files here, or
            click to select files.
          </p>
        )}
      </div>

      {files.length > 0 && (
        <div className="mt-4">
          <SubmitButton
            isLoading={isProcessing}
            size="medium"
          >
            Process Files
          </SubmitButton>
        </div>
      )}
    </div>
  );
};

export default FilePreview;
