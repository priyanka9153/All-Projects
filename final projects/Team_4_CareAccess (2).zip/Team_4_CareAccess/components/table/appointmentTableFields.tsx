// columns.tsx
'use client';
import { ColumnDef } from '@tanstack/react-table';
import { format } from 'date-fns';
import { Doctors } from '@/constants';
import { patientAppointment } from '@/types/appwrite.types';
import { AppointmentWindow } from '../AppointmentWindow';
import { Statecondition } from '../Statecondition';
import { DoctorProfile } from '../DoctorProfile';

export const appointmentTableColumns: ColumnDef<patientAppointment>[] =
  [
    {
      header: '#',
      cell: ({ row }) => {
        return (
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-100 text-blue-600 font-medium">
            {row.index + 1}
          </div>
        );
      },
    },
    {
      accessorKey: 'patient',
      header: 'Patient',
      cell: ({ row }) => {
        const patientAppointment =
          row.original;
        return (
          <div className="flex flex-col">
            <p className="text-base font-medium text-gray-900">
              {
                patientAppointment
                  .patient.name
              }
            </p>
            <p className="text-sm text-gray-500">
              ID:{' '}
              {patientAppointment.patient.$id.slice(
                0,
                8,
              )}
            </p>
          </div>
        );
      },
    },
    {
      accessorKey: 'primaryPhysician',
      header: 'Doctor',
      cell: ({ row }) => {
        const patientAppointment =
          row.original;
        const doctor = Doctors.find(
          (doctor) =>
            doctor.name ===
            patientAppointment.primaryPhysician,
        );

        if (!doctor) return null;

        return (
          <DoctorProfile
            {...doctor}
            compact={true}
          />
        );
      },
    },
    {
      accessorKey: 'schedule',
      header: 'Appointment',
      cell: ({ row }) => {
        const patientAppointment =
          row.original;
        const date = new Date(
          patientAppointment.schedule,
        );

        return (
          <div className="flex flex-col">
            <p className="font-medium text-gray-900">
              {format(
                date,
                'MM/dd/yyyy',
              )}
            </p>
            <p className="text-sm text-gray-500">
              {format(date, 'hh:mm a')}
            </p>
          </div>
        );
      },
    },
    {
      accessorKey: 'status',
      header: 'Status',
      cell: ({ row }) => {
        const patientAppointment =
          row.original;
        return (
          <div className="min-w-[130px]">
            <Statecondition
              status={
                patientAppointment.status
              }
            />
          </div>
        );
      },
    },
    {
      id: 'actions',
      header: () => (
        <div className="pl-4 font-medium text-gray-900">
          Actions
        </div>
      ),
      cell: ({ row }) => {
        const patientAppointment =
          row.original;
        return (
          <div className="flex gap-2">
            <AppointmentWindow
              patientId={
                patientAppointment
                  .patient.$id
              }
              userId={
                patientAppointment.userId
              }
              patientAppointment={
                patientAppointment
              }
              type="schedule"
              title="Schedule Appointment"
              description="Please confirm the following details to schedule."
            />
            <AppointmentWindow
              patientId={
                patientAppointment
                  .patient.$id
              }
              userId={
                patientAppointment.userId
              }
              patientAppointment={
                patientAppointment
              }
              type="cancel"
              title="Cancel Appointment"
              description="Are you sure you want to cancel your appointment?"
            />
          </div>
        );
      },
    },
  ];
