import Image from 'next/image';
import { Button } from './styling/button';
import { Statecondition } from './Statecondition';

interface ButtonProps {
  isLoading: boolean;
  className?: string;
  children: React.ReactNode;
  icon?: string;
  size?: 'small' | 'medium' | 'large';
  loadingText?: string;
}

const SubmitButton = ({
  isLoading,
  className,
  children,
  icon,
  size,
  loadingText = 'Processing...',
}: ButtonProps) => {
  const sizeClasses = {
    small:
      'px-3 py-1.5 text-sm rounded-md',
    medium:
      'px-5 py-2.5 text-base rounded-lg',
    large:
      'px-7 py-3.5 text-lg rounded-xl',
  };

  const defaultClass =
    'shad-primary-btn bg-blue-600 text-white hover:bg-blue-700 disabled:bg-blue-300 w-full';
  const buttonClass =
    className ?? defaultClass;

  return (
    <Button
      type="submit"
      disabled={isLoading}
      className={`${buttonClass} ${sizeClasses[size || 'medium']} transition duration-300 ease-in-out`}
      aria-busy={isLoading}
    >
      {isLoading ? (
        <div className="flex items-center gap-3">
          <Image
            src="/assets/icons/loader.svg"
            alt="Loading"
            width={28}
            height={28}
            className="animate-spin"
          />
          <span className="text-white">
            {loadingText}
          </span>
        </div>
      ) : (
        <div className="flex items-center gap-3">
          {icon && (
            <Image
              src={icon}
              alt={`${children} Icon`} // Improved accessibility
              width={28}
              height={28}
              className="rounded-sm"
            />
          )}
          <span className="font-medium">
            {children}
          </span>
        </div>
      )}
    </Button>
  );
};

export default SubmitButton;
