'use client';

import {
  useState,
  useEffect,
} from 'react';
import { Button } from '@/components/styling/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/styling/dialog';
import {
  Calendar,
  Clock,
} from 'lucide-react';
import { patientAppointment } from '@/types/appwrite.types';
import { AppointmentBooking } from './forms/AppointmentBooking';
import 'react-datepicker/dist/react-datepicker.css';

export const AppointmentWindow = ({
  patientId,
  userId,
  patientAppointment,
  type,
  title,
  description,
}: {
  patientId: string;
  userId: string;
  patientAppointment?: patientAppointment;
  type: 'schedule' | 'cancel';
  title: string;
  description: string;
}) => {
  const [open, setOpen] =
    useState(false);

  useEffect(() => {
    console.log(
      `Component mounted with type: ${type}`,
    );
  }, [type]);

  return (
    <Dialog
      open={open}
      onOpenChange={(isOpen) => {
        console.log(
          `Dialog state changed: ${isOpen ? 'Opened' : 'Closed'}`,
        );
        setOpen(isOpen);
      }}
    >
      <DialogTrigger asChild>
        <Button
          variant={
            type === 'schedule'
              ? 'default'
              : 'destructive'
          }
          className={`
            flex items-center gap-4 rounded-lg px-8 py-3 
            ${
              type === 'schedule'
                ? 'bg-blue-500 hover:bg-blue-600 text-white'
                : 'bg-purple-500 hover:bg-purple-600 text-white'
            }
          `}
        >
          {type === 'schedule' ? (
            <Calendar className="h-5 w-5" />
          ) : (
            <Clock className="h-5 w-5" />
          )}
          {type
            .charAt(0)
            .toUpperCase() +
            type.slice(1)}
        </Button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-lg bg-gray-100 dark:bg-gray-800 rounded-xl shadow-md border">
        <DialogHeader className="space-y-6 pb-6 border-b dark:border-gray-600">
          <DialogTitle className="text-3xl font-semibold text-gray-800 dark:text-gray-100 capitalize flex items-center gap-3">
            {type === 'schedule' ? (
              <Calendar className="h-7 w-7 text-blue-500" />
            ) : (
              <Clock className="h-7 w-7 text-purple-500" />
            )}
            {title ||
              `${type} patientAppointment`}
          </DialogTitle>
          <DialogDescription className="text-gray-600 dark:text-gray-300 text-lg">
            {description ||
              `Please fill in the following details to ${type} an appointment.`}
          </DialogDescription>
        </DialogHeader>

        <div className="p-6 bg-gray-200 dark:bg-gray-900 rounded-xl mt-6">
          <AppointmentBooking
            userId={userId}
            patientId={patientId}
            type={type}
            patientAppointment={
              patientAppointment
            }
            setOpen={setOpen}
          />
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AppointmentWindow;
