'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { infer, z } from 'zod';

import {
  Form,
  FormControl,
} from '@/components/styling/form';
import { Label } from '@/components/styling/label';
import {
  RadioGroup,
  RadioGroupItem,
} from '@/components/styling/radio-group';
import { SelectItem } from '@/components/styling/select';
import {
  Doctors,
  GenderOptions,
  IdentificationTypes,
  PatientSignupDefaultValues,
} from '@/constants';
import { registerPatient } from '@/controller/operations/user.operations';
import { PatientSchema } from '@/controller/authentication';

import 'react-datepicker/dist/react-datepicker.css';
import 'react-phone-number-input/style.css';
import CustomEntryField, {
  FormFieldType,
} from '../CustomEntryField';
import { FileUploader } from '../FilePoster';
import SubmitButton from '../SubmitButton';
import { log } from 'console';
import { type } from 'os';

interface User {
  $id: string;
  name: string;
  email: string;
  phone: string;
}

const NewUserForm = ({
  user,
}: {
  user: User;
}) => {
  const router = useRouter();
  const [isLoading, setIsLoading] =
    useState(false);

  const form = useForm<
    z.infer<typeof PatientSchema>
  >({
    resolver: zodResolver(
      PatientSchema,
    ),
    defaultValues: {
      ...PatientSignupDefaultValues,
      name: user.name,
      email: user.email,
      phone: user.phone,
    },
  });

  const onSubmit = async (
    values: z.infer<
      typeof PatientFormValidation
    >,
  ) => {
    console.log('clicked2');
    setIsLoading(true);

    // Store file info in form data as
    let formData;
    if (
      values.identificationDocument &&
      values.identificationDocument
        ?.length > 0
    ) {
      const blobFile = new Blob(
        [
          values
            .identificationDocument[0],
        ],
        {
          type: values
            .identificationDocument[0]
            .type,
        },
      );

      formData = new FormData();
      formData.append(
        'blobFile',
        blobFile,
      );
      formData.append(
        'fileName',
        values.identificationDocument[0]
          .name,
      );
    }
    console.log('name-', values.email);
    console.log('email-', values.name);
    try {
      const patient = {
        userId: user.$id,
        name: values.name,
        email: values.email,
        phone: values.phone,
        birthDate: new Date(
          values.birthDate,
        ),
        gender: values.gender,
        address: values.address,
        occupation: values.occupation,
        emergencyContactName:
          values.emergencyContactName,
        emergencyContactNumber:
          values.emergencyContactNumber,
        primaryPhysician:
          values.primaryPhysician,
        insuranceProvider:
          values.insuranceProvider,
        insurancePolicyNumber:
          values.insurancePolicyNumber,
        allergies: values.allergies,
        currentMedication:
          values.currentMedication,
        familyMedicalHistory:
          values.familyMedicalHistory,
        pastMedicalHistory:
          values.pastMedicalHistory,
        identificationType:
          values.identificationType,
        identificationNumber:
          values.identificationNumber,
        identificationDocument:
          values.identificationDocument
            ? formData
            : undefined,
        privacyConsent:
          values.privacyConsent,
      };
      console.log('Clicke!!!');
      console.log('patient-', patient);
      const newPatient =
        await registerPatient(patient);
      console.log(
        'newpatient-',
        newPatient,
      );
      if (newPatient) {
        router.push(
          `/patients/${user.$id}/new-appointment`,
        );
      }
    } catch (error) {
      console.log('There is an error!');
      console.log(error);
    }

    setIsLoading(false);
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-blue-50 to-white px-4 py-8">
      <div className="mx-auto max-w-7xl">
        <div className="rounded-xl bg-white p-8 shadow-lg">
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(
                onSubmit,
              )}
              className="flex-1 space-y-12"
            >
              <section className="space-y-4">
                <h1 className="header">
                  Welcome 👋
                </h1>
                <p className="text-dark-700">
                  Tell us a bit about
                  yourself.
                </p>
              </section>

              <section className="space-y-6">
                <div className="mb-9 space-y-1">
                  <h2 className="sub-header">
                    Your Details
                  </h2>
                </div>

                <CustomEntryField
                  fieldType={
                    FormFieldType.INPUT
                  }
                  control={form.control}
                  name="name"
                  placeholder="Full Name"
                  iconSrc="/assets/icons/user.svg"
                  iconAlt="user"
                />

                <div className="flex flex-col gap-6 xl:flex-row">
                  <CustomEntryField
                    fieldType={
                      FormFieldType.INPUT
                    }
                    control={
                      form.control
                    }
                    name="email"
                    label="Your Email"
                    placeholder="email@example.com"
                    iconSrc="/assets/icons/email.svg"
                    iconAlt="email"
                  />

                  <CustomEntryField
                    fieldType={
                      FormFieldType.PHONE_INPUT
                    }
                    control={
                      form.control
                    }
                    name="phone"
                    label="Your Phone"
                    placeholder="Your phone number"
                  />
                </div>

                <div className="flex flex-col gap-6 xl:flex-row">
                  <CustomEntryField
                    fieldType={
                      FormFieldType.DATE_PICKER
                    }
                    control={
                      form.control
                    }
                    name="birthDate"
                    label="Date of Birth"
                  />

                  <CustomEntryField
                    fieldType={
                      FormFieldType.SKELETON
                    }
                    control={
                      form.control
                    }
                    name="gender"
                    label="Your Gender"
                    renderSkeleton={(
                      field,
                    ) => (
                      <FormControl>
                        <RadioGroup
                          className="flex h-11 gap-6 xl:justify-between"
                          onValueChange={
                            field.onChange
                          }
                          defaultValue={
                            field.value
                          }
                        >
                          {GenderOptions.map(
                            (
                              option,
                              i,
                            ) => (
                              <div
                                key={
                                  option +
                                  i
                                }
                                className="radio-group"
                              >
                                <RadioGroupItem
                                  value={
                                    option
                                  }
                                  id={
                                    option
                                  }
                                />
                                <Label
                                  htmlFor={
                                    option
                                  }
                                  className="cursor-pointer"
                                >
                                  {
                                    option
                                  }
                                </Label>
                              </div>
                            ),
                          )}
                        </RadioGroup>
                      </FormControl>
                    )}
                  />
                </div>

                <div className="flex flex-col gap-6 xl:flex-row">
                  <CustomEntryField
                    fieldType={
                      FormFieldType.INPUT
                    }
                    control={
                      form.control
                    }
                    name="address"
                    label="Home Address"
                    placeholder="123 Your Street, City, State"
                  />

                  <CustomEntryField
                    fieldType={
                      FormFieldType.INPUT
                    }
                    control={
                      form.control
                    }
                    name="occupation"
                    label="Your Job"
                    placeholder="Your occupation"
                  />
                </div>

                <div className="flex flex-col gap-6 xl:flex-row">
                  <CustomEntryField
                    fieldType={
                      FormFieldType.INPUT
                    }
                    control={
                      form.control
                    }
                    name="emergencyContactName"
                    label="Emergency Contact"
                    placeholder="Name of emergency contact"
                  />

                  <CustomEntryField
                    fieldType={
                      FormFieldType.PHONE_INPUT
                    }
                    control={
                      form.control
                    }
                    name="emergencyContactNumber"
                    label="Emergency Phone"
                    placeholder="Emergency contact number"
                  />
                </div>
              </section>

              <section className="space-y-6">
                <div className="mb-9 space-y-1">
                  <h2 className="sub-header">
                    Health Background
                  </h2>
                </div>

                <CustomEntryField
                  fieldType={
                    FormFieldType.SELECT
                  }
                  control={form.control}
                  name="primaryPhysician"
                  label="Choose Your Doctor"
                  placeholder="Select your doctor"
                >
                  {Doctors.map(
                    (doctor, i) => (
                      <SelectItem
                        key={
                          doctor.name +
                          i
                        }
                        value={
                          doctor.name
                        }
                      >
                        <div className="flex cursor-pointer items-center gap-2">
                          <Image
                            src={
                              doctor.image
                            }
                            width={32}
                            height={32}
                            alt={
                              doctor.name
                            }
                            className="rounded-full border border-dark-500"
                          />
                          <p>
                            {
                              doctor.name
                            }
                          </p>
                        </div>
                      </SelectItem>
                    ),
                  )}
                </CustomEntryField>

                <div className="flex flex-col gap-6 xl:flex-row">
                  <CustomEntryField
                    fieldType={
                      FormFieldType.INPUT
                    }
                    control={
                      form.control
                    }
                    name="insuranceProvider"
                    label="Health Insurance"
                    placeholder="Name of insurance provider"
                  />

                  <CustomEntryField
                    fieldType={
                      FormFieldType.INPUT
                    }
                    control={
                      form.control
                    }
                    name="insurancePolicyNumber"
                    label="Policy Number"
                    placeholder="Your policy number"
                  />
                </div>

                <div className="flex flex-col gap-6 xl:flex-row">
                  <CustomEntryField
                    fieldType={
                      FormFieldType.TEXTAREA
                    }
                    control={
                      form.control
                    }
                    name="allergies"
                    label="List Allergies"
                    placeholder="List known allergies"
                  />

                  <CustomEntryField
                    fieldType={
                      FormFieldType.TEXTAREA
                    }
                    control={
                      form.control
                    }
                    name="currentMedication"
                    label="Current Medications"
                    placeholder="List current medications"
                  />
                </div>

                <div className="flex flex-col gap-6 xl:flex-row">
                  <CustomEntryField
                    fieldType={
                      FormFieldType.TEXTAREA
                    }
                    control={
                      form.control
                    }
                    name="familyMedicalHistory"
                    label="Family Health History"
                    placeholder="Family health background"
                  />

                  <CustomEntryField
                    fieldType={
                      FormFieldType.TEXTAREA
                    }
                    control={
                      form.control
                    }
                    name="pastMedicalHistory"
                    label="Your Medical History"
                    placeholder="Your past medical events"
                  />
                </div>
              </section>

              <section className="space-y-6">
                <div className="mb-9 space-y-1">
                  <h2 className="sub-header">
                    ID Verification
                  </h2>
                </div>

                <CustomEntryField
                  fieldType={
                    FormFieldType.SELECT
                  }
                  control={form.control}
                  name="identificationType"
                  label="ID Type"
                  placeholder="Select type of ID"
                >
                  {IdentificationTypes.map(
                    (type, i) => (
                      <SelectItem
                        key={type + i}
                        value={type}
                      >
                        {type}
                      </SelectItem>
                    ),
                  )}
                </CustomEntryField>

                <CustomEntryField
                  fieldType={
                    FormFieldType.INPUT
                  }
                  control={form.control}
                  name="identificationNumber"
                  label="ID Number"
                  placeholder="Your identification number"
                />

                <CustomEntryField
                  fieldType={
                    FormFieldType.SKELETON
                  }
                  control={form.control}
                  name="identificationDocument"
                  label="Upload ID Document"
                  renderSkeleton={(
                    field,
                  ) => (
                    <FormControl>
                      <FileUploader
                        files={
                          field.value
                        }
                        onChange={
                          field.onChange
                        }
                      />
                    </FormControl>
                  )}
                />
              </section>

              <section className="space-y-6">
                <div className="mb-9 space-y-1">
                  <h2 className="sub-header">
                    Privacy Agreement
                  </h2>
                </div>

                <CustomEntryField
                  fieldType={
                    FormFieldType.CHECKBOX
                  }
                  control={form.control}
                  name="treatmentConsent"
                  label="Consent to Treatment"
                />

                <CustomEntryField
                  fieldType={
                    FormFieldType.CHECKBOX
                  }
                  control={form.control}
                  name="disclosureConsent"
                  label="Consent to Health Information Disclosure"
                />

                <CustomEntryField
                  fieldType={
                    FormFieldType.CHECKBOX
                  }
                  control={form.control}
                  name="privacyConsent"
                  label="Agree to Privacy Policy"
                />
              </section>
              <button
                type="submit"
                onClick={onSubmit}
              >
                Submit
              </button>
              {/* <SubmitButton
              
                isLoading={isLoading}
                className="w-full py-3 px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-md"
              >
                Submit and Proceed
              </SubmitButton> */}
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
};

export default NewUserForm;
