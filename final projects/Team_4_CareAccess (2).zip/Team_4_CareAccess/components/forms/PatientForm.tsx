// components/PatientForm.tsx
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import NewFormFields, {
  FormFieldType,
} from '../CustomEntryField';
import { Form } from '@/components/styling/form';
import SubmitButton from '../SubmitButton';
import { z } from 'zod';
import { UserFormValidation } from '@/controller/authentication';

interface PatientFormProps {
  onSubmit: (
    values: z.infer<
      typeof UserFormValidation
    >,
  ) => void;
  isLoading: boolean;
}

const PatientForm: React.FC<
  PatientFormProps
> = ({ onSubmit, isLoading }) => {
  const form = useForm<
    z.infer<typeof UserFormValidation>
  >({
    resolver: zodResolver(
      UserFormValidation,
    ),
    defaultValues: {
      name: '',
      email: '',
      phone: '',
    },
  });

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(
          onSubmit,
        )}
        className="flex-1 space-y-8"
      >
        <section className="mb-8 space-y-6">
          <h1 className="text-3xl font-extrabold text-indigo-800">
            Welcome to CareAccess
          </h1>
          <p className="text-lg text-gray-700">
            Register here to get
            started.
          </p>
        </section>

        <div className="border-gray-300 hover:border-indigo-500 focus:ring-indigo-500">
          <NewFormFields
            fieldType={
              FormFieldType.INPUT
            }
            control={form.control}
            name="name"
            label="Full name"
            placeholder="Rajesh Kumar"
            iconSrc="/assets/icons/user.svg"
            iconAlt="user"
          />
        </div>

        <div className="border-gray-300 hover:border-indigo-500 focus:ring-indigo-500">
          <NewFormFields
            fieldType={
              FormFieldType.INPUT
            }
            control={form.control}
            name="email"
            label="Email"
            placeholder="rajeshkumar@example.com"
            iconSrc="/assets/icons/email.svg"
            iconAlt="email"
          />
        </div>

        <div className="border-gray-300 hover:border-indigo-500 focus:ring-indigo-500">
          <NewFormFields
            fieldType={
              FormFieldType.PHONE_INPUT
            }
            control={form.control}
            name="phone"
            label="Contact Number"
            placeholder="+91 98765 43210"
          />
        </div>

        <SubmitButton
          isLoading={isLoading}
          className="w-full py-3 px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-md"
        >
          Get Started
        </SubmitButton>
      </form>
    </Form>
  );
};

export default PatientForm;
import { FC } from 'react';
import { infer } from 'zod';
