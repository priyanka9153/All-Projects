import { FC } from 'react';
import CustomEntryField, { FormFieldType } from '../CustomEntryField';
import { SelectItem } from '@/components/styling/select';
import { Doctors } from '@/constants';

const NewFormFields: FC<{
  type: 'create' | 'schedule' | 'cancel';
  form: any;
  patientAppointment?: any;
}> = ({ type, form, patientAppointment }) => (
  <>
    {type === 'create' && (
      <section className="mb-12 space-y-4">
        <h1 className="header">Book an Appointment</h1>
        <p className="text-dark-700">Schedule your appointment effortlessly in just a few clicks</p>
      </section>
    )}
    {type !== 'cancel' && (
      <>
        <CustomEntryField
          fieldType={FormFieldType.SELECT}
          control={form.control}
          name="primaryPhysician"
          label="Doctor"
          placeholder="Select a doctor"
        >
          {Doctors.map((doctor, index) => (
            <SelectItem key={doctor.name + index} value={doctor.name}>
              <div className="flex cursor-pointer items-center gap-2">
                <img
                  src={doctor.image}
                  width={32}
                  height={32}
                  alt="doctor"
                  className="rounded-full border border-dark-500"
                />
                <p>{doctor.name}</p>
              </div>
            </SelectItem>
          ))}
        </CustomEntryField>

        <CustomEntryField
          fieldType={FormFieldType.DATE_PICKER}
          control={form.control}
          name="schedule"
          label="Preferred Appointment Date"
          showTimeSelect
          dateFormat="MM/dd/yyyy  -  h:mm aa"
        />

        <div className="flex flex-col gap-6">
          <CustomEntryField
            fieldType={FormFieldType.TEXTAREA}
            control={form.control}
            name="reason"
            label="Reason for Appointment"
            placeholder="Annual check-up or monthly follow-up"
            disabled={type === 'schedule'}
          />
          <CustomEntryField
            fieldType={FormFieldType.TEXTAREA}
            control={form.control}
            name="note"
            label="Additional Comments"
            placeholder="Prefer afternoon slots if available"
            disabled={type === 'schedule'}
          />
        </div>
      </>
    )}
    {type === 'cancel' && (
      <CustomEntryField
        fieldType={FormFieldType.TEXTAREA}
        control={form.control}
        name="appointmentCancelReason"
        label="Cancellation Reason"
        placeholder="Unexpected commitments or urgent work"
      />
    )}
  </>
);

export default NewFormFields;
