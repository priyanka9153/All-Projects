// components/NewPatient.tsx
'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { CreateUser } from '@/controller/operations/user.operations';
import PatientForm from './PatientForm';

export const NewPatient = () => {
  const router = useRouter();
  const [isLoading, setIsLoading] =
    useState(false);

  const onSubmit = async (values: {
    name: string;
    email: string;
    phone: string;
  }) => {
    setIsLoading(true);
    console.log('clicked!');
    try {
      const user = {
        name: values.name,
        email: values.email,
        phone: values.phone,
      };

      const newUser =
        await CreateUser(user);

      if (newUser) {
        router.push(
          `/Users/${newUser.$id}/Signup`,
        );
      }
    } catch (error) {
      console.log(error);
    }

    setIsLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-indigo-100 via-white to-indigo-200 px-6 py-10">
      <div className="w-full max-w-xl p-8 bg-white shadow-2xl rounded-2xl border border-gray-200">
        <PatientForm
          onSubmit={onSubmit}
          isLoading={isLoading}
        />
      </div>
    </div>
  );
};
