'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useRouter } from 'next/navigation';
import {
  Dispatch,
  SetStateAction,
  useState,
} from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';

import { loadAppointmentSchema } from '@/controller/authentication';
import { patientAppointment } from '@/types/appwrite.types';
import {
  scheduleAppointment,
  modifyAppointment,
} from '@/controller/operations/appointment.operations';
import NewFormFields from './NewFormFields';
import SubmitButton from '../SubmitButton';
import { Form } from '../styling/form';

export const AppointmentBooking = ({
  userId,
  patientId,
  type = 'create',
  patientAppointment,
  setOpen,
}: {
  userId: string;
  patientId: string;
  type:
    | 'create'
    | 'schedule'
    | 'cancel';
  patientAppointment?: patientAppointment;
  setOpen?: Dispatch<
    SetStateAction<boolean>
  >;
}) => {
  const router = useRouter();
  const [isLoading, setIsLoading] =
    useState(false);

  const AppointmentBookingValidation =
    loadAppointmentSchema(type);

  const form = useForm<
    z.infer<
      typeof AppointmentBookingValidation
    >
  >({
    resolver: zodResolver(
      AppointmentBookingValidation,
    ),
    defaultValues: {
      primaryPhysician:
        patientAppointment?.attendingPhysician ||
        '',
      schedule: patientAppointment
        ? new Date(
            patientAppointment?.appointmentSchedule!,
          )
        : new Date(),
      reason:
        patientAppointment?.appointmentReason ||
        '',
      note:
        patientAppointment?.note || '',
      appointmentCancelReason:
        patientAppointment?.appointmentCancellationReason ||
        '',
    },
  });

  const onSubmit = async (
    values: z.infer<
      typeof AppointmentBookingValidation
    >,
  ) => {
    setIsLoading(true);
    let status;
    switch (type) {
      case 'schedule':
        status = 'scheduled';
        break;
      case 'cancel':
        status = 'cancelled';
        break;
      default:
        status = 'pending';
    }

    try {
      if (
        type === 'create' &&
        patientId
      ) {
        const appointment = {
          userId,
          patient: patientId,
          primaryPhysician:
            values.primaryPhysician,
          schedule: new Date(
            values.schedule,
          ),
          reason: values.reason!,
          status: status as Status,
          note: values.note,
        };

        const newAppointment =
          await scheduleAppointment(
            appointment,
          );

        if (newAppointment) {
          form.reset();
          router.push(
            `/Users/${userId}/Create-Appointment/Confirm?appointmentId=${newAppointment.$id}`,
          );
        }
      } else {
        const appointmentToUpdate = {
          userId,
          appointmentId:
            patientAppointment?.$id!,
          appointment: {
            primaryPhysician:
              values.primaryPhysician,
            schedule: new Date(
              values.schedule,
            ),
            status: status as Status,
            appointmentCancelReason:
              values.appointmentCancelReason,
          },
          type,
        };

        const updatedAppointment =
          await modifyAppointment(
            appointmentToUpdate,
          );

        if (updatedAppointment) {
          setOpen && setOpen(false);
          form.reset();
        }
      }
    } catch (error) {
      console.log(error);
    }
    setIsLoading(false);
  };

  let buttonLabel;
  switch (type) {
    case 'cancel':
      buttonLabel =
        'Cancel Appointment';
      break;
    case 'schedule':
      buttonLabel =
        'Schedule Appointment';
      break;
    default:
      buttonLabel =
        'Submit Appointment';
  }

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(
          onSubmit,
        )}
        className="flex-1 space-y-6"
      >
        <NewFormFields
          type={type}
          form={form}
          patientAppointment={
            patientAppointment
          }
        />
        <SubmitButton
          isLoading={isLoading}
          className={`${type === 'cancel' ? 'shad-danger-btn' : 'shad-primary-btn'} w-full`}
        >
          {buttonLabel}
        </SubmitButton>
      </form>
    </Form>
  );
};
