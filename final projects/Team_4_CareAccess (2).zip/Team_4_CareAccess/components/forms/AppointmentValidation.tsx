import {
  object,
  string,
  optional,
} from 'zod';
import { z } from 'zod';

export const loadAppointmentSchema = (
  type:
    | 'create'
    | 'schedule'
    | 'cancel',
) => {
  switch (type) {
    case 'create':
      return z.object({
        primaryPhysician: z
          .string()
          .min(1, 'Doctor is required'),
        schedule: z
          .string()
          .min(
            1,
            'Appointment date is required',
          ),
        reason: z
          .string()
          .min(
            1,
            'Reason for appointment is required',
          ),
        note: z.string().optional(),
      });
    case 'schedule':
      return z.object({
        primaryPhysician: z
          .string()
          .min(1, 'Doctor is required'),
        schedule: z
          .string()
          .min(
            1,
            'Appointment date is required',
          ),
        reason: z.string().optional(),
        note: z.string().optional(),
      });
    case 'cancel':
      return z.object({
        appointmentCancelReason: z
          .string()
          .min(
            1,
            'Cancellation reason is required',
          ),
      });
    default:
      return z.object({});
  }
};
