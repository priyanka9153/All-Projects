'use client';

import { useState } from 'react';
import { Statecondition } from './Statecondition';

const NotificationBanner = () => {
  const [currentStatus, setCurrentStatus] = useState<'info' | 'warning' | 'error'>('info');

  const toggleStatus = () => {
    const statuses = ['info', 'warning', 'error'] as const;
    const nextStatus = statuses[(statuses.indexOf(currentStatus) + 1) % statuses.length];
    setCurrentStatus(nextStatus);
  };

  const statusConfig = {
    info: {
      label: 'Information',
      message: 'This is an informational banner.',
    },
    warning: {
      label: 'Warning',
      message: 'This is a warning banner. Please pay attention.',
    },
    error: {
      label: 'Error',
      message: 'This is an error banner. Something went wrong.',
    },
  };

  return (
    <div className="max-w-xl mx-auto p-4 bg-white rounded-lg shadow-md">
     <div className="mt-4">
        <h3 className="text-lg font-semibold text-gray-800">{statusConfig[currentStatus].label}</h3>
        <p className="text-sm text-gray-600">{statusConfig[currentStatus].message}</p>
      </div>
      <button
        onClick={toggleStatus}
        className="mt-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white py-2 px-4 rounded-lg hover:opacity-90 transition duration-300"
      >
        Toggle Status
      </button>
    </div>
  );
};

export default NotificationBanner;
