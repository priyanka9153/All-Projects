import Image from 'next/image';
import { Star, Clock, Globe } from 'lucide-react';

interface DoctorProfileProps {
  image: string;
  name: string;
  specialization?: string;
  rating?: number;
  experience?: string;
  availability?: boolean;
  consultations?: string;
  languages?: string[];
  compact?: boolean;
}

export const DoctorProfile = ({
  image,
  name,
  specialization = 'Primary Physician',
  rating = 4.8,
  experience,
  availability = true,
  consultations,
  languages,
  compact = false,
}: DoctorProfileProps) => {
  if (compact) {
    return (
      <div className="flex items-center gap-4">
        <div className="relative">
          <Image
            src={image}
            alt={name}
            width={56}
            height={56}
            className="rounded-full border-2 border-gray-200"
          />
          {availability && (
            <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-green-600 border-2 border-gray-50" />
          )}
        </div>
        <div>
          <p className="font-medium text-gray-800">
            Dr. {name}
          </p>
          <p className="text-sm text-gray-500">
            {specialization}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start gap-5 p-5 rounded-xl hover:bg-gray-100 transition duration-300">
      <div className="relative">
        <Image
          src={image}
          alt={name}
          width={72}
          height={72}
          className="rounded-full border-2 border-gray-300 shadow-md"
        />
        {availability && (
          <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-green-500 border-2 border-gray-50" />
        )}
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-3">
          <h3 className="text-xl font-semibold text-gray-900">
            Dr. {name}
          </h3>
          {availability && (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 shadow-sm">
              Available
            </span>
          )}
        </div>

        <p className="text-sm text-gray-600">
          {specialization}
        </p>

        <div className="flex items-center gap-5 mt-2 text-sm text-gray-600">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
            <span>{rating}/5</span>
          </div>
          {experience && (
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-500" />
              <span>{experience}</span>
            </div>
          )}
          {languages && (
            <div className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-teal-500" />
              <span>{languages.join(', ')}</span>
            </div>
          )}
        </div>

        {consultations && (
          <p className="text-sm text-gray-500 mt-2">
            {consultations} consultations
          </p>
        )}
      </div>
    </div>
  );
};
