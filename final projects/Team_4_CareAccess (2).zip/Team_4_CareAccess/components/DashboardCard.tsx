import clsx from 'clsx';
import Image from 'next/image';
import FilePreview from './Flepreview';
type DashboardCardProps = {
  type:
    | 'cancelled'
    | 'pending'
    | 'appointmentData'
    | 'completed';
  count: number;
  label: string;
  icon: string;
  className?: string;
};

export const DashboardCard = ({
  type,
  count,
  label,
  icon,
  className,
}: DashboardCardProps) => {
  const baseStyle =
    'flex flex-col items-center justify-center p-10 rounded-xl shadow-lg transition duration-300 ease-in-out';
  const colorStyles = {
    appointmentdata:
      'bg-blue-400 hover:bg-blue-500 text-blue-800',
    pending:
      'bg-yellow-400 hover:bg-yellow-500 text-yellow-800',
    cancelled:
      'bg-red-400 hover:bg-red-500 text-red-800',
  };

  return (
    <div
      className={clsx(
        baseStyle,
        colorStyles[type],
        className,
      )}
    >
      <Image
        src={icon}
        height={50}
        width={50}
        alt={label}
        className="mb-4"
      />
      <h2 className="text-xl font-extrabold">
        {count}
      </h2>
      <p className="text-md font-medium">
        {label}
      </p>

      <div className="mt-2 text-xs text-gray-600 dark:text-gray-400">
        {type === 'appointmentData' &&
          'Track all scheduled appointments'}
        {type === 'pending' &&
          'Pending tasks or actions'}
        {type === 'cancelled' &&
          'Cancelled events or actions'}
      </div>
    </div>
  );
};
