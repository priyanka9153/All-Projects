'use client';

import React, { useState, useEffect, useCallback } from 'react';
import * as DialogPrimitive from '@radix-ui/react-dialog';
import { X, CheckCircle, ArrowRight } from 'lucide-react'; // Icons for custom buttons

import { cn } from '@/controller/utils';

const Dialog = DialogPrimitive.Root;

const DialogTrigger = DialogPrimitive.Trigger;

const DialogPortal = DialogPrimitive.Portal;

const DialogClose = DialogPrimitive.Close;

const DialogOverlay = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Overlay
    ref={ref}
    className={cn(
      'fixed inset-0 z-50 bg-gradient-to-r from-cyan-500/70 to-teal-500/70 backdrop-blur-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 dark:bg-gradient-to-r dark:from-slate-900 dark:to-gray-800 dark:backdrop-blur-lg',
      className,
    )}
    {...props}
  />
));
DialogOverlay.displayName = DialogPrimitive.Overlay.displayName;

const DialogContent = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Content>
>(({ className, children, ...props }, ref) => (
  <DialogPortal>
    <DialogOverlay />
    <DialogPrimitive.Content
      ref={ref}
      className={cn(
        'fixed left-[50%] top-[50%] z-50 grid w-full max-w-xl translate-x-[-50%] translate-y-[-50%] gap-6 border-4 border-dotted border-gray-300 rounded-2xl bg-white p-8 sm:p-10 shadow-2xl shadow-cyan-500/30 duration-300 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] dark:border-gray-700 dark:bg-gray-900 dark:bg-pattern-dark dark:shadow-teal-900/40',
        className,
      )}
      {...props}
    >
      <div className="flex flex-col items-center justify-center space-y-6 text-center">
        {children}
      </div>
      <DialogPrimitive.Close className="absolute right-5 top-5 flex items-center justify-center w-10 h-10 rounded-full bg-teal-500 hover:bg-teal-600 text-white transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-teal-300 focus:ring-offset-2 dark:bg-gray-700 dark:hover:bg-gray-600 dark:ring-offset-gray-900">
        <X className="w-5 h-5" />
        <span className="sr-only">Close</span>
      </DialogPrimitive.Close>
    </DialogPrimitive.Content>
  </DialogPortal>
));
DialogContent.displayName = DialogPrimitive.Content.displayName;

const DialogHeader = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      'flex flex-col space-y-3 sm:space-y-2 text-center sm:text-left font-sans',
      className,
    )}
    {...props}
  />
);
DialogHeader.displayName = 'DialogHeader';

const DialogFooter = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      'flex flex-col-reverse sm:flex-row sm:justify-between sm:space-x-6 space-y-3 sm:space-y-0 p-5 border-t border-gray-200 dark:border-gray-700',
      className,
    )}
    {...props}
  >
    <DialogPrimitive.Close asChild>
      <button className="flex items-center justify-center w-full sm:w-auto px-5 py-3 rounded-xl text-teal-600 hover:bg-teal-50 transition-all duration-300 dark:text-teal-400 dark:hover:bg-gray-800">
        Cancel
      </button>
    </DialogPrimitive.Close>
    <button className="flex items-center justify-center px-5 py-3 rounded-xl text-white bg-teal-600 hover:bg-teal-700 transition-all duration-300 dark:bg-teal-500 dark:hover:bg-teal-600">
      Confirm
      <ArrowRight className="ml-3 w-5 h-5" />
    </button>
  </div>
);
DialogFooter.displayName = 'DialogFooter';

const DialogTitle = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Title
    ref={ref}
    className={cn(
      'text-3xl sm:text-4xl font-extrabold text-teal-600 leading-snug tracking-tight font-serif dark:text-teal-400',
      className,
    )}
    {...props}
  />
));
DialogTitle.displayName = DialogPrimitive.Title.displayName;

const DialogDescription = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Description>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Description
    ref={ref}
    className={cn(
      'text-lg sm:text-xl text-gray-700 dark:text-gray-400 font-normal font-sans',
      className,
    )}
    {...props}
  />
));
DialogDescription.displayName = DialogPrimitive.Description.displayName;

// Debug utility for monitoring dialog usage
const dialogLogger = (() => {
  let dialogOpenCount = 0;
  return {
    logOpen: () => {
      dialogOpenCount++;
      console.log('Dialog opened:', dialogOpenCount, 'times');
    },
  };
})();

export {
  Dialog,
  DialogPortal,
  DialogOverlay,
  DialogClose,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
  dialogLogger,
};
