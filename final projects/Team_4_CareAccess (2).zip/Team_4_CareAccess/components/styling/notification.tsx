import React from 'react';
import { cn } from '@/controller/utils';
import { XCircle, CheckCircle, Info, AlertTriangle } from 'lucide-react';

export interface NotificationProps {
  type?: 'success' | 'error' | 'info' | 'warning';
  message: string;
  onClose?: () => void;
}

const icons = {
  success: <CheckCircle className="h-5 w-5 text-green-500" />,
  error: <XCircle className="h-5 w-5 text-red-500" />,
  info: <Info className="h-5 w-5 text-blue-500" />,
  warning: <AlertTriangle className="h-5 w-5 text-yellow-500" />,
};

const Notification = ({
  type = 'info',
  message,
  onClose,
}: NotificationProps) => {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-md border p-4 shadow-sm',
        type === 'success' && 'border-green-500 bg-green-50 dark:bg-green-800',
        type === 'error' && 'border-red-500 bg-red-50 dark:bg-red-800',
        type === 'info' && 'border-blue-500 bg-blue-50 dark:bg-blue-800',
        type === 'warning' && 'border-yellow-500 bg-yellow-50 dark:bg-yellow-800',
      )}
    >
      {icons[type]}
      <span className="text-sm font-medium text-gray-700 dark:text-gray-200">
        {message}
      </span>
      {onClose && (
        <button
          onClick={onClose}
          className="ml-auto text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
        >
          ×
        </button>
      )}
    </div>
  );
};

export { Notification };
