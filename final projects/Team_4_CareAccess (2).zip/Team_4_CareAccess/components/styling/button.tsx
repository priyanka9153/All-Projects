import React, { useState, useEffect } from 'react';
import { Slot } from '@radix-ui/react-slot';
import { cva, type VariantProps } from 'class-variance-authority';

import { cn } from '@/controller/utils';


const buttonVariants = cva(
  'inline-flex items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-800 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:bg-gray-300 disabled:text-gray-500 dark:ring-offset-slate-800 dark:focus-visible:ring-slate-200',
  {
    variants: {
      variant: {
        default:
          'bg-slate-800 text-white hover:bg-slate-700 dark:bg-slate-200 dark:text-slate-800 dark:hover:bg-slate-300',
        primary:
          'bg-blue-600 text-white hover:bg-blue-700 dark:bg-blue-800 dark:hover:bg-blue-900',
        info: 'bg-blue-200 text-blue-800 hover:bg-blue-300 dark:bg-blue-700 dark:text-blue-100 dark:hover:bg-blue-600',
        warning:
          'bg-yellow-500 text-yellow-800 hover:bg-yellow-600 dark:bg-yellow-700 dark:text-yellow-100 dark:hover:bg-yellow-800',
        destructive:
          'bg-red-600 text-white hover:bg-red-700 dark:bg-red-800 dark:text-white dark:hover:bg-red-900',
        outline:
          'border border-slate-300 bg-white hover:bg-slate-200 hover:text-slate-800 dark:border-slate-700 dark:bg-slate-900 dark:hover:bg-slate-800 dark:hover:text-slate-100',
        secondary:
          'bg-slate-200 text-slate-800 hover:bg-slate-300 dark:bg-slate-700 dark:text-slate-100 dark:hover:bg-slate-600',
        ghost:
          'hover:bg-slate-200 hover:text-slate-800 dark:hover:bg-slate-700 dark:hover:text-slate-100',
        link: 'text-slate-800 underline-offset-4 hover:underline dark:text-slate-100',
        accent:
          'bg-green-500 text-white hover:bg-green-600 dark:bg-green-700 dark:hover:bg-green-800', // Added custom variant
      },
      size: {
        xs: 'h-7 px-3 py-1 text-xs',
        sm: 'h-10 px-4 py-2',
        default: 'h-12 px-5 py-2',
        lg: 'h-15 px-7 py-3',
        xl: 'h-17 px-9 py-4',
        icon: 'size-12',
      },
      shape: {
        default: 'rounded-md',
        pill: 'rounded-full',
        square: 'rounded-none',
        ellipse: 'rounded-lg', // Added custom shape
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
      shape: 'default',
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.memo(
  React.forwardRef<HTMLButtonElement, ButtonProps>(
    (
      {
        className,
        variant,
        size,
        shape,
        asChild = false,
        ...props
      },
      ref,
    ) => {
      const Comp = asChild ? Slot : 'button';
      return (
        <Comp
          className={cn(
            buttonVariants({
              variant,
              size,
              shape,
              className,
            }),
          )}
          ref={ref}
          {...props}
        />
      );
    },
  ),
);

Button.displayName = 'Button';


const buttonCountTracker = (() => {
  let count = 0;
  return {
    increment: () => count++,
    getCount: () => count,
  };
})();
console.log('Current Button Count:', buttonCountTracker.getCount());

export { Button, buttonVariants };
