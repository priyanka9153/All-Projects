'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { OTPInput, OTPInputContext } from 'input-otp';
import { Dot } from 'lucide-react';

import { cn } from '@/controller/utils';

const InputOTP = React.forwardRef<
  React.ElementRef<typeof OTPInput>,
  React.ComponentPropsWithoutRef<typeof OTPInput>
>(
  ({ className, containerClassName, ...props }, ref) => (
    <OTPInput
      ref={ref}
      containerClassName={cn(
        'flex items-center gap-3 has-[:disabled]:opacity-60',
        containerClassName,
      )}
      className={cn(
        'disabled:cursor-not-allowed text-gray-800 dark:text-gray-100',
        className,
      )}
      {...props}
    />
  ),
);
InputOTP.displayName = 'InputOTP';

const InputOTPGroup = React.forwardRef<
  React.ElementRef<'div'>,
  React.ComponentPropsWithoutRef<'div'>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn('flex items-center gap-4', className)}
    {...props}
  />
));
InputOTPGroup.displayName = 'InputOTPGroup';

const InputOTPSlot = React.forwardRef<
  React.ElementRef<'div'>,
  React.ComponentPropsWithoutRef<'div'> & {
    index: number;
  }
>(({ index, className, ...props }, ref) => {
  const inputOTPContext = React.useContext(OTPInputContext);
  const { char, hasFakeCaret, isActive } = inputOTPContext.slots[index];

  return (
    <div
      ref={ref}
      className={cn(
        'relative flex h-12 w-12 items-center justify-center border-y border-r border-gray-300 text-lg transition-all first:rounded-l-md first:border-l last:rounded-r-md dark:border-gray-700 dark:bg-gray-800',
        isActive &&
          'z-10 ring-2 ring-blue-500 ring-offset-white dark:ring-blue-300 dark:ring-offset-gray-900',
        className,
      )}
      {...props}
    >
      {char}
      {hasFakeCaret && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="h-6 w-px animate-caret-blink bg-blue-500 duration-700 dark:bg-blue-300" />
        </div>
      )}
    </div>
  );
});
InputOTPSlot.displayName = 'InputOTPSlot';

const InputOTPSeparator = React.forwardRef<
  React.ElementRef<'div'>,
  React.ComponentPropsWithoutRef<'div'>
>(({ ...props }, ref) => (
  <div ref={ref} role="separator" className="mx-2" {...props}>
    <Dot className="text-gray-400 dark:text-gray-600" />
  </div>
));
InputOTPSeparator.displayName = 'InputOTPSeparator';

// Debug utility to log OTP inputs
const otpLogger = (() => {
  let inputCount = 0;
  return {
    logInput: () => {
      inputCount++;
      console.log('OTP input received:', inputCount, 'times');
    },
  };
})();

export {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
  InputOTPSeparator,
  otpLogger,
};
