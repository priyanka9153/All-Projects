import React, { useState, useEffect, useCallback } from 'react';
import { cn } from '@/controller/utils';

// Define the properties accepted by the Input component, including value and onChange for controlled components
export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  value?: string;
  onChange?: React.ChangeEventHandler<HTMLInputElement>;
}

const Input = React.forwardRef<
  HTMLInputElement,
  InputProps
>(
  ({ className, type, value, onChange, ...props }, ref) => {
    return (
      <input
        type={type}
        value={value}
        onChange={onChange}
        className={cn(
          'flex h-12 w-full rounded-lg border border-gray-300 bg-gray-50 px-4 py-3 text-base ring-offset-white file:border-0 file:bg-transparent file:text-base file:font-medium placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-60 dark:border-gray-700 dark:bg-gray-900 dark:ring-offset-gray-900 dark:placeholder:text-gray-400 dark:focus-visible:ring-blue-300',
          className,
        )}
        ref={ref}
        {...props}
      />
    );
  },
);
Input.displayName = 'Input';

// Example useReducer usage for more complex input handling
function useInput(initialValue: string) {
  const [value, dispatch] = React.useReducer(
    (
      state: string,
      action: { type: string; payload?: string },
    ) => {
      switch (action.type) {
        case 'change':
          return action.payload ?? state;
        default:
          return state;
      }
    },
    initialValue,
  );

  const handleChange: React.ChangeEventHandler<HTMLInputElement> = (e) => {
    dispatch({
      type: 'change',
      payload: e.target.value,
    });
  };

  return [value, handleChange] as const;
}

// Debug utility to track input changes
const inputLogger = (() => {
  let changeCount = 0;
  return {
    logChange: (value: string) => {
      changeCount++;
      console.log(`Input changed ${changeCount} times. Current value: "${value}"`);
    },
  };
})();

export { Input, useInput, inputLogger };
