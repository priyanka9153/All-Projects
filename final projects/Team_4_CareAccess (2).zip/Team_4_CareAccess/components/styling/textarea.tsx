import React from 'react';

import { cn } from '@/controller/utils';

export interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

const Textarea = React.forwardRef<
  HTMLTextAreaElement,
  TextareaProps
>(({ className, ...props }, ref) => {
  return (
    <textarea
      className={cn(
        'flex min-h-[100px] w-full rounded-lg border border-gray-300 bg-gray-50 px-4 py-3 text-base text-gray-700 shadow-sm ring-offset-white placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-60 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-100 dark:ring-offset-gray-900 dark:placeholder:text-gray-400 dark:focus-visible:ring-blue-300',
        className,
      )}
      ref={ref}
      {...props}
    />
  );
});
Textarea.displayName = 'Textarea';


export const TextareaWithCounter = ({
  maxLength,
  value,
  className,
  ...props
}: TextareaProps & { maxLength: number }) => {
  return (
    <div className="relative">
      <Textarea
        value={value}
        maxLength={maxLength}
        className={cn('mb-6', className)}
        {...props}
      />
      {maxLength && (
        <div className="absolute bottom-2 right-3 text-sm text-gray-500 dark:text-gray-400">
          {value?.toString().length || 0}/{maxLength}
        </div>
      )}
    </div>
  );
};

export { Textarea };
