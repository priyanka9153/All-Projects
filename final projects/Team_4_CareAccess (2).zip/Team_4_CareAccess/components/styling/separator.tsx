'use client';

import React from 'react';
import * as SeparatorPrimitive from '@radix-ui/react-separator';

import { cn } from '@/controller/utils';

const Separator = React.forwardRef<
  React.ElementRef<typeof SeparatorPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof SeparatorPrimitive.Root>
>(
  ({ className, orientation = 'horizontal', decorative = true, ...props }, ref) => (
    <SeparatorPrimitive.Root
      ref={ref}
      decorative={decorative}
      orientation={orientation}
      className={cn(
        'shrink-0 bg-gray-300 dark:bg-gray-700',
        orientation === 'horizontal'
          ? 'h-[2px] w-full'
          : 'h-full w-[2px]',
        className,
      )}
      {...props}
    />
  ),
);
Separator.displayName = SeparatorPrimitive.Root.displayName;


const SeparatorLabel = ({
  children,
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & { children: React.ReactNode }) => (
  <div
    className={cn(
      'flex items-center justify-center text-sm font-medium text-gray-500 dark:text-gray-400 px-2',
      className,
    )}
    {...props}
  >
    {children}
  </div>
);

const LabeledSeparator = ({
  label,
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & { label?: string }) => (
  <div className={cn('flex items-center gap-2', className)} {...props}>
    <Separator orientation="horizontal" className="flex-grow" />
    {label && <SeparatorLabel>{label}</SeparatorLabel>}
    <Separator orientation="horizontal" className="flex-grow" />
  </div>
);

export { Separator, SeparatorLabel, LabeledSeparator };
