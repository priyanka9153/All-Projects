import React from 'react';
import { cn } from '@/controller/utils';

export interface CardProps {
  header?: React.ReactNode;
  body: React.ReactNode;
  footer?: React.ReactNode;
}

const Card = ({
  header,
  body,
  footer,
  className,
  ...props
}: CardProps & React.HTMLAttributes<HTMLDivElement>) => {
  return (
    <div
      className={cn(
        'rounded-lg border border-gray-300 bg-white shadow-md dark:border-gray-700 dark:bg-gray-800',
        className,
      )}
      {...props}
    >
      {header && (
        <div className="border-b border-gray-200 p-4 dark:border-gray-700">
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
            {header}
          </h3>
        </div>
      )}
      <div className="p-4 text-gray-700 dark:text-gray-300">{body}</div>
      {footer && (
        <div className="border-t border-gray-200 p-4 dark:border-gray-700">
          {footer}
        </div>
      )}
    </div>
  );
};

export { Card };
