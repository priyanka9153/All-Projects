import React, { useState } from 'react';
import { cn } from '@/controller/utils';

export interface TabsProps {
  tabs: { id: string; label: string }[];
  onChange?: (id: string) => void;
}

const Tabs = ({ tabs, onChange }: TabsProps) => {
  const [activeTab, setActiveTab] = useState(tabs[0]?.id);

  const handleTabChange = (id: string) => {
    setActiveTab(id);
    if (onChange) onChange(id);
  };

  return (
    <div>
      <div className="flex border-b border-gray-200 dark:border-gray-700">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => handleTabChange(tab.id)}
            className={cn(
              'px-4 py-2 text-sm font-medium focus:outline-none',
              activeTab === tab.id
                ? 'border-b-2 border-blue-500 text-blue-500 dark:border-blue-300 dark:text-blue-300'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300',
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div className="p-4 text-gray-700 dark:text-gray-300">
        {tabs.find((tab) => tab.id === activeTab)?.label} Content
      </div>
    </div>
  );
};

export { Tabs };
