'use client';

import React, { useState, useEffect, useCallback } from 'react';
import * as PopoverPrimitive from '@radix-ui/react-popover';

import { cn } from '@/controller/utils';

const Popover = PopoverPrimitive.Root;

const PopoverTrigger = PopoverPrimitive.Trigger;

const PopoverContent = React.forwardRef<
  React.ElementRef<typeof PopoverPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof PopoverPrimitive.Content>
>(
  ({ className, align = 'center', sideOffset = 6, ...props }, ref) => (
    <PopoverPrimitive.Portal>
      <PopoverPrimitive.Content
        ref={ref}
        align={align}
        sideOffset={sideOffset}
        className={cn(
          'z-50 w-80 rounded-lg border border-gray-300 bg-gray-50 p-6 text-gray-900 shadow-lg outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-100',
          className,
        )}
        {...props}
      >
        <div className="flex flex-col gap-2">
          <h3 className="text-lg font-bold text-gray-700 dark:text-gray-300">
            Popover Title
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            This is an example of additional content inside the popover.
          </p>
          <button className="mt-2 rounded-md bg-blue-500 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-500">
            Action Button
          </button>
        </div>
      </PopoverPrimitive.Content>
    </PopoverPrimitive.Portal>
  ),
);
PopoverContent.displayName = PopoverPrimitive.Content.displayName;

// Debug utility for tracking popover openings
const popoverLogger = (() => {
  let openCount = 0;
  return {
    logOpen: () => {
      openCount++;
      console.log(`Popover opened ${openCount} times`);
    },
  };
})();

export {
  Popover,
  PopoverTrigger,
  PopoverContent,
  popoverLogger,
};
