import React from 'react';
import { cn } from '@/controller/utils';

export interface InputGroupProps {
  label: string;
  error?: string;
  children: React.ReactNode;
}

const InputGroup = ({
  label,
  error,
  children,
}: InputGroupProps & React.HTMLAttributes<HTMLDivElement>) => {
  return (
    <div className="mb-4">
      <label
        className={cn(
          'block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300',
        )}
      >
        {label}
      </label>
      {children}
      {error && (
        <p className="mt-2 text-sm text-red-500 dark:text-red-400">{error}</p>
      )}
    </div>
  );
};

export { InputGroup };
