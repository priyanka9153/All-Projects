import clsx from 'clsx';
import Image from 'next/image';
import { StatusIcon } from '@/constants';

export const Statecondition = ({
  status,
}: {
  status: Status;
}) => {
  const getStatusConfig = (
    status: Status,
  ) => {
    const configs = {
      scheduled: {
        bgColor: 'bg-green-100',
        textColor: 'text-green-800',
        borderColor: 'border-green-300',
        iconBg: 'bg-green-200',
      },
      pending: {
        bgColor: 'bg-blue-100',
        textColor: 'text-blue-800',
        borderColor: 'border-blue-300',
        iconBg: 'bg-blue-200',
      },
      cancelled: {
        bgColor: 'bg-red-100',
        textColor: 'text-red-800',
        borderColor: 'border-red-300',
        iconBg: 'bg-red-200',
      },
    };
    return configs[status];
  };

  const config =
    getStatusConfig(status);

  return (
    <div
      className={clsx(
        'flex items-center gap-3 px-4 py-2 rounded-lg border transition-all duration-300 ease-in-out',
        'hover:shadow-md',
        config.bgColor,
        config.borderColor,
      )}
    >
      <div
        className={clsx(
          'flex items-center justify-center p-1.5 rounded-full shadow-sm',
          config.iconBg,
        )}
      >
        <Image
          src={StatusIcon[status]}
          alt={`${status} status`}
          width={28}
          height={28}
          className="h-5 w-5 object-contain"
        />
      </div>
      <span
        className={clsx(
          'text-md font-medium capitalize tracking-wide',
          config.textColor,
        )}
      >
        {status === 'scheduled'
          ? 'Scheduled'
          : status === 'pending'
            ? 'Awaiting Action'
            : 'Cancelled'}
      </span>
    </div>
  );
};
