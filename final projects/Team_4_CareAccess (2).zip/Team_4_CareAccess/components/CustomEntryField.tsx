/* eslint-disable no-unused-vars */
import { E164Number } from 'libphonenumber-js/core';
import Image from 'next/image';
import ReactDatePicker from 'react-datepicker';
import { Control } from 'react-hook-form';
import PhoneInput from 'react-phone-number-input';
import NotificationBanner from './NotificationBanner';

import { Checkbox } from './styling/checkbox';
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from './styling/form';
import { Input } from './styling/input';
import {
  Select,
  SelectContent,
  SelectTrigger,
  SelectValue,
} from './styling/select';
import { Textarea } from './styling/textarea';

export enum FormFieldType {
  INPUT = 'input',
  TEXTAREA = 'textarea',
  PHONE_INPUT = 'phoneInput',
  CHECKBOX = 'checkbox',
  DATE_PICKER = 'datePicker',
  SELECT = 'select',
  SKELETON = 'skeleton',
}

interface CustomProps {
  control: Control<any>;
  name: string;
  label?: string;
  placeholder?: string;
  iconSrc?: string;
  iconAlt?: string;
  disabled?: boolean;
  dateFormat?: string;
  showTimeSelect?: boolean;
  children?: React.ReactNode;
  renderSkeleton?: (
    field: any,
  ) => React.ReactNode;
  fieldType: FormFieldType;
}

const RenderInput = ({
  field,
  props,
}: {
  field: any;
  props: CustomProps;
}) => {
  switch (props.fieldType) {
    case FormFieldType.INPUT:
      return (
        <div className="flex rounded-xl border border-light-400 bg-gray-100 dark:bg-gray-700 p-3 shadow-md">
          {props.iconSrc && (
            <Image
              src={props.iconSrc}
              height={30}
              width={30}
              alt={
                props.iconAlt || 'icon'
              }
              className="ml-4"
            />
          )}
          <FormControl>
            <Input
              placeholder={
                props.placeholder
              }
              {...field}
              className="new-input-style border-0 focus:ring-blue-600 dark:focus:ring-blue-500"
            />
          </FormControl>
        </div>
      );
    case FormFieldType.TEXTAREA:
      return (
        <FormControl>
          <Textarea
            placeholder={
              props.placeholder
            }
            {...field}
            className="new-textArea-style rounded-lg shadow-sm bg-gray-50 dark:bg-gray-800"
            disabled={props.disabled}
          />
        </FormControl>
      );
    case FormFieldType.PHONE_INPUT:
      return (
        <FormControl>
          <PhoneInput
            defaultCountry="US"
            placeholder={
              props.placeholder
            }
            international
            withCountryCallingCode
            value={
              field.value as
                | E164Number
                | undefined
            }
            onChange={field.onChange}
            className="new-phone-style border-gray-300 dark:border-gray-600 rounded-md"
          />
        </FormControl>
      );
    case FormFieldType.CHECKBOX:
      return (
        <FormControl>
          <div className="flex items-center gap-6">
            <Checkbox
              id={props.name}
              checked={field.value}
              onCheckedChange={
                field.onChange
              }
              className="custom-checkbox focus:ring-green-600"
            />
            <label
              htmlFor={props.name}
              className="checkbox-label text-gray-900 dark:text-gray-200"
            >
              {props.label}
            </label>
          </div>
        </FormControl>
      );
    case FormFieldType.DATE_PICKER:
      return (
        <div className="flex rounded-xl border border-gray-400 bg-gray-50 dark:bg-gray-900 p-4 shadow-lg">
          <Image
            src="/assets/icons/new-calendar-icon.svg"
            height={30}
            width={30}
            alt="Calendar"
            className="ml-4"
          />
          <FormControl>
            <ReactDatePicker
              showTimeSelect={
                props.showTimeSelect ??
                false
              }
              selected={field.value}
              onChange={(date: Date) =>
                field.onChange(date)
              }
              timeInputLabel="Time:"
              dateFormat={
                props.dateFormat ??
                'MM/dd/yyyy'
              }
              wrapperClassName="date-picker rounded-lg focus:ring-yellow-600"
            />
          </FormControl>
        </div>
      );
    case FormFieldType.SELECT:
      return (
        <FormControl>
          <Select
            onValueChange={
              field.onChange
            }
            defaultValue={field.value}
          >
            <FormControl>
              <SelectTrigger className="custom-select-trigger shadow-md border-0 rounded-lg">
                <SelectValue
                  placeholder={
                    props.placeholder
                  }
                />
              </SelectTrigger>
            </FormControl>
            <SelectContent className="custom-select-content bg-white dark:bg-gray-900 shadow-lg">
              {props.children}
            </SelectContent>
          </Select>
        </FormControl>
      );
    case FormFieldType.SKELETON:
      return props.renderSkeleton
        ? props.renderSkeleton(field)
        : null;
    default:
      return null;
  }
};

const CustomEntryField = (
  props: CustomProps,
) => {
  const { control, name, label } =
    props;

  return (
    <FormField
      control={control}
      name={name}
      render={({ field }) => (
        <FormItem className="flex-1 custom-form-item border-gray-300 dark:border-gray-700 p-6 rounded-xl shadow-md">
          {props.fieldType !==
            FormFieldType.CHECKBOX &&
            label && (
              <FormLabel className="custom-input-label text-gray-800 dark:text-gray-300">
                {label}
              </FormLabel>
            )}
          <RenderInput
            field={field}
            props={props}
          />

          <FormMessage className="custom-error-message text-red-500 dark:text-red-400" />
        </FormItem>
      )}
    />
  );
};

export default CustomEntryField;
