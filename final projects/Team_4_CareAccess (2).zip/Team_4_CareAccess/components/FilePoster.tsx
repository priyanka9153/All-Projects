'use client';

import Image from 'next/image';
import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';

import { convertFileToUrl } from '@/controller/utils';

type FileUploaderProps = {
  files: File[] | undefined;
  onChange: (files: File[]) => void;
};

export const FileUploader = ({ files, onChange }: FileUploaderProps) => {
  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      onChange(acceptedFiles);
    },
    [onChange]
  );

  const { getRootProps, getInputProps } = useDropzone({ onDrop });

  return (
    <div
      {...getRootProps()}
      className="file-upload p-6 border-2 border-dashed rounded-xl border-gray-300 hover:border-blue-500 transition duration-300 ease-in-out cursor-pointer"
    >
      <input {...getInputProps()} />
      {files && files?.length > 0 ? (
        <Image
          src={convertFileToUrl(files[0])}
          width={800}
          height={400}
          alt="uploaded image"
          className="max-h-[500px] w-auto overflow-hidden object-cover rounded-lg shadow-md"
        />
      ) : (
        <>
          <Image
            src="/assets/icons/upload.svg"
            width={50}
            height={50}
            alt="upload"
            className="mb-4"
          />
          <div className="file-upload_label text-center">
            <p className="text-base font-medium text-gray-700">
              <span className="text-blue-600">
                Click to upload{' '}
              </span>
              or drag and drop
            </p>
            <p className="text-sm text-gray-500">
              SVG, PNG, JPG or GIF (max. 1200x800px)
            </p>
          </div>
        </>
      )}
    </div>
  );
};
