import { z } from 'zod';

export const UserFormValidation = z.object({
  name: z
    .string()
    .min(4, 'Name must have at least 4 characters')
    .max(50, 'Name cannot exceed 50 characters'),
  email: z
    .string()
    .email('Please enter a valid email address'),
  phone: z
    .string()
    .refine(
      (phone) => /^\+\d{10,15}$/.test(phone),
      'Phone number must include the country code and be between 10 to 15 digits',
    ),
});

export const PatientSchema = z.object({
  name: z
    .string()
    .min(4, 'Name must have at least 4 characters')
    .max(50, 'Name cannot exceed 50 characters'),
  email: z
    .string()
    .email('Please enter a valid email address'),
  phone: z
    .string()
    .refine(
      (phone) => /^\+\d{10,15}$/.test(phone),
      'Phone number must include the country code and be between 10 to 15 digits',
    ),
  birthDate: z.coerce.date(),
  gender: z.enum(['Male', 'Female', 'Other']),
  address: z
    .string()
    .min(4, 'Address must have at least 4 characters')
    .max(500, 'Address cannot exceed 500 characters'),
  occupation: z
    .string()
    .min(4, 'Occupation must have at least 4 characters')
    .max(500, 'Occupation cannot exceed 500 characters'),
  emergencyContactName: z
    .string()
    .min(4, 'Emergency contact name must have at least 4 characters')
    .max(50, 'Emergency contact name cannot exceed 50 characters'),
  emergencyContactNumber: z
    .string()
    .refine(
      (emergencyContactNumber) =>
        /^\+\d{10,15}$/.test(emergencyContactNumber),
      'Emergency contact number must include the country code and be between 10 to 15 digits',
    ),
  primaryPhysician: z
    .string()
    .min(4, 'Doctor name must have at least 4 characters'),
  insuranceProvider: z
    .string()
    .min(4, 'Insurance provider name must have at least 4 characters')
    .max(50, 'Insurance provider name cannot exceed 50 characters'),
  insurancePolicyNumber: z
    .string()
    .min(4, 'Policy number must have at least 4 characters')
    .max(50, 'Policy number cannot exceed 50 characters'),
  allergies: z.string().optional(),
  currentMedication: z.string().optional(),
  familyMedicalHistory: z.string().optional(),
  pastMedicalHistory: z.string().optional(),
  identificationType: z.string().optional(),
  identificationNumber: z.string().optional(),
  identificationDocument: z.custom<File[]>().optional(),
  maritalStatus: z.string().optional(),
  languagePreference: z.string().optional(),
  preferredContactMethod: z.string().optional(),
  bloodType: z.string().optional(),
  smokingStatus: z.string().optional(),
  height: z.number().optional(),
  weight: z.number().optional(),
  treatmentConsent: z
    .boolean()
    .default(false)
    .refine((value) => value === true, {
      message: 'Consent for treatment is required to continue',
    }),
  disclosureConsent: z
    .boolean()
    .default(false)
    .refine((value) => value === true, {
      message: 'Disclosure consent is required to continue',
    }),
  privacyConsent: z
    .boolean()
    .default(false)
    .refine((value) => value === true, {
      message: 'Privacy consent is required to continue',
    }),
});

export const CreateAppointmentSchema = z.object({
  primaryPhysician: z
    .string()
    .min(4, 'Doctor name must have at least 4 characters'),
  schedule: z.coerce.date(),
  reason: z
    .string()
    .min(4, 'Reason for the appointment must have at least 4 characters')
    .max(500, 'Reason cannot exceed 500 characters'),
  note: z.string().optional(),
  appointmentCancelReason: z.string().optional(),
});

export const ScheduleAppointmentSchema = z.object({
  primaryPhysician: z
    .string()
    .min(4, 'Doctor name must have at least 4 characters'),
  schedule: z.coerce.date(),
  reason: z.string().optional(),
  note: z.string().optional(),
  appointmentCancelReason: z.string().optional(),
});

export const CancelAppointmentSchema = z.object({
  primaryPhysician: z
    .string()
    .min(4, 'Doctor name must have at least 4 characters'),
  schedule: z.coerce.date(),
  reason: z.string().optional(),
  note: z.string().optional(),
  appointmentCancelReason: z
    .string()
    .min(4, 'Cancellation reason must have at least 4 characters')
    .max(500, 'Cancellation reason cannot exceed 500 characters'),
});

export function loadAppointmentSchema(type: string) {
  switch (type) {
    case 'create':
      return CreateAppointmentSchema;
    case 'cancel':
      return CancelAppointmentSchema;
    default:
      return ScheduleAppointmentSchema;
  }
}
