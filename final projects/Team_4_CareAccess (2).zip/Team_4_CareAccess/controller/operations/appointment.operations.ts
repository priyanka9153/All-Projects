'use server';

import { revalidatePath } from 'next/cache';
import {
  ID,
  Query,
} from 'node-appwrite';

import { patientAppointment } from '@/types/appwrite.types';

import {
  INFO_APPOINTMENTS,
  INFO_DB,
  databases,
  messaging,
} from '../model.config';
import {
  formatDateTime,
  parseStringify,
} from '../utils';
import { scheduleAppointmentParams, modifyAppointmentParams } from '@/types';

// CREATE APPOINTMENT
export const scheduleAppointment =
  async (
    patientAppointment: scheduleAppointmentParams,
  ) => {
    try {
      // Proceed to create the appointment
      const newAppointment =
        await databases.createDocument(
          INFO_DB!,
          INFO_APPOINTMENTS!,
          ID.unique(),
          patientAppointment,
        );

      revalidatePath('/admin');
      return parseStringify(
        newAppointment,
      );
    } catch (error) {
      console.error(
        'Error while creating a new appointment:',
        error,
      );
      throw error; // Re-throw the error to handle it in the calling function
    }
  };

// GET RECENT APPOINTMENTS
export const fetchRecentAppointments =
  async () => {
    try {
      const appointmentData =
        await databases.listDocuments(
          INFO_DB!,
          INFO_APPOINTMENTS!,
          [
            Query.orderDesc(
              '$createdAt',
            ),
          ],
        );

      const initialCounts = {
        confirmedAppointments: 0,
        awaitingConfirmation: 0,
        cancelledAppointments: 0,
        rescheduledCount: 0, // Added rescheduled count
      };

      const counts = (
        appointmentData.documents as patientAppointment[]
      ).reduce((acc, appointment) => {
        switch (appointment.status) {
          case 'scheduled':
            acc.confirmedAppointments++;
            break;
          case 'pending':
            acc.awaitingConfirmation++;
            break;
          case 'cancelled':
            acc.cancelledAppointments++;
            break;
          case 'rescheduled':
            acc.rescheduledCount++;
            break;
        }
        return acc;
      }, initialCounts);

      const data = {
        totalCount:
          appointmentData.total,
        ...counts,
        documents:
          appointmentData.documents,
      };

      return parseStringify(data);
    } catch (error) {
      console.error(
        'Error while retrieving recent appointments:',
        error,
      );
    }
  };

// SEND SMS NOTIFICATION
export const sendSMSNotification =
  async (
    userId: string,
    content: string,
  ) => {
    try {
      const message =
        await messaging.createSms(
          ID.unique(),
          content,
          [],
          [userId],
        );
      return parseStringify(message);
    } catch (error) {
      console.error(
        'Error while sending SMS notification:',
        error,
      );
    }
  };

// UPDATE APPOINTMENT
export const modifyAppointment =
  async ({
    appointmentId,
    userId,
    timeZone,
    patientAppointment,
    type,
  }: modifyAppointmentParams) => {
    try {
      // Proceed to update the appointment
      const updatedAppointment =
        await databases.updateDocument(
          INFO_DB!,
          INFO_APPOINTMENTS!,
          appointmentId,
          patientAppointment,
        );

      if (!updatedAppointment)
        throw new Error(
          'Failed to update the appointment.',
        );

      const smsMessage = `Greetings from CareAccess. ${type === 'schedule'
        ? `Your appointment is confirmed for ${formatDateTime(
          patientAppointment.schedule!,
          timeZone,
        ).dateTime
        } with Dr. ${patientAppointment.primaryPhysician}`
        : `We regret to inform that your appointment for ${formatDateTime(
          patientAppointment.schedule!,
          timeZone,
        ).dateTime
        } is cancelled. Reason: ${patientAppointment.appointmentCancelReason}`
        }`;

      await sendSMSNotification(
        userId,
        smsMessage,
      );

      revalidatePath('/admin');
      return parseStringify(
        updatedAppointment,
      );
    } catch (error) {
      console.error(
        'Error while modifying an appointment:',
        error,
      );
      throw error; // Re-throw the error to handle it in the calling function
    }
  };

// GET APPOINTMENT
export const retrieveAppointment =
  async (appointmentId: string) => {
    try {
      const patientAppointment =
        await databases.getDocument(
          INFO_DB!,
          INFO_APPOINTMENTS!,
          appointmentId,
        );

      return parseStringify(
        patientAppointment,
      );
    } catch (error) {
      console.error(
        'Error while retrieving the appointment:',
        error,
      );
    }
  };
