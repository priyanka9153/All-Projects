Hosital-Management-System-DBMS

Technologies Used:
Frontend : React.js
Backend : Node.js, Express
Database : MySQL


Instructions to run:

1. Run "npm install" in frontend and backend directories.

2. Run "npm start" first in the backend and then in the frontend directory.

3. Access localhost:3000 from the browser.

