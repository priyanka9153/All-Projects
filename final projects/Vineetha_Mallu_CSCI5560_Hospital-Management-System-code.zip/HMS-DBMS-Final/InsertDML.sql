INSERT INTO Patient(email,password,name,address,gender)
VALUES
('priya@gmail.com','priya','priya','vizag', 'female'),
('gk@gmail.com','gk','gk','Hyderabad ', 'female'),
('siddhu@gmail.com','siddhu','siddhu','Nellore ', 'male')
;

INSERT INTO Admin(email,password,name,PhoneNumber)
VALUES
('padma@gmail.com','padma','padma','6292515713'),
('vineetha@gmail.com','vineetha','vineetha','6291456713 '),
('kumari@gmail.com','kumari','kumari','6298123443 ')
;

INSERT INTO Staff(email,password,name,PhoneNumber,gender)
VALUES
('kuncham@gmail.com','kuncham','kuncham','vizag', 'female'),
('mallu@gmail.com','mallu','mallu','Hyderabad ', 'female'),
('chedella@gmail.com','chedella','chedella','Nellore ', 'male')
;


INSERT INTO MedicalHistory(id,date,conditions,surgeries,medication)
VALUES
(1,'19-01-14','Pain in abdomen','Heart Surgery','Crocin'),
(2,'19-01-14','Frequent Indigestion','none','none'),
(3,'19-01-14','Body Pain','none','Iodex')
;

INSERT INTO Doctor(email, gender, password, name)
VALUES
('sathya@gmail.com', 'male', 'sathya', 'Sathya'),
('venkat@gmail.com', 'male', 'venkat', 'Venkat')
;

INSERT INTO Appointment(id,date,starttime,endtime,status)
VALUES
(1, '24-04-16', '09:00', '10:00', 'Done'),
(2, '24-04-17', '10:00', '11:00', 'Done'),
(3, '24-04-18', '14:00', '15:00', 'Done')
;

INSERT INTO PatientsAttendAppointments(patient,appt,concerns,symptoms)
VALUES
('priya@gmail.com',1, 'none', 'itchy throat'),
('gk@gmail.com',2, 'infection', 'fever'),
('siddhu@gmail.com',3, 'nausea', 'fever')
;

INSERT INTO Schedule(id,starttime,endtime,breaktime,day)
VALUES
(001,'09:00','17:00','12:00','Tuesday'),
(001,'09:00','17:00','12:00','Friday'),
(001,'09:00','17:00','12:00','Saturday'),
(001,'09:00','17:00','12:00','Sunday'),
(002,'09:00','17:00','12:00','Wednesday'),
(002,'09:00','17:00','12:00','Friday')
;

INSERT INTO PatientsFillHistory(patient,history)
VALUES
('priya@gmail.com', 1),
('gk@gmail.com', 2),
('siddhu@gmail.com', 3)
;

INSERT INTO Diagnose(appt,doctor,diagnosis,prescription)
VALUES
(1,'sathya@gmail.com', 'Bloating', 'Ibuprofen as needed'),
(2,'venkat@gmail.com', 'Muscle soreness', 'Stretch morning/night'),
(3,'venkat@gmail.com', 'Vitamin Deficiency', 'Good Diet')
;

INSERT INTO DocsHaveSchedules(sched,doctor)
VALUES
(001,'sathya@gmail.com'),
(002,'venkat@gmail.com')
;

INSERT INTO DoctorViewsHistory(history,doctor)
VALUES
(1,'sathya@gmail.com'),
(2,'venkat@gmail.com'),
(3,'venkat@gmail.com')
;
